<?php
// ============================================================
// MobileFix - Database Connection (PDO singleton)
// ============================================================

$config = require __DIR__ . '/config.php';
date_default_timezone_set($config['app']['timezone']);

function db(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $config = require __DIR__ . '/config.php';
        $db = $config['database'];

        $dsn = "mysql:host={$db['host']};dbname={$db['dbname']};charset={$db['charset']}";

        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];

        try {
            $pdo = new PDO($dsn, $db['username'], $db['password'], $options);
        } catch (PDOException $e) {
            http_response_code(500);
            die('<div style="font-family:sans-serif;max-width:520px;margin:80px auto;padding:24px;border:1px solid #eee;border-radius:12px">
                 <h2 style="margin:0 0 8px">Database connection failed</h2>
                 <p style="color:#666">Please make sure the <code>mobilefix</code> database exists.
                 Run <a href="install.php">install.php</a> first, then check your credentials in
                 <code>config/config.php</code>.</p>
                 <p style="color:#a00;font-size:0.85em">' . htmlspecialchars($e->getMessage()) . '</p>
                 </div>');
        }
    }

    return $pdo;
}
