<?php
// ============================================================
// MobileFix - Application Configuration
// ============================================================
return [
    'app' => [
        'name'       => 'MobileFix',
        'tagline'    => 'Repair Management System',
        'timezone'   => 'Africa/Lagos',
        'currency'   => '₦',
        'date_format' => 'd M Y H:i',
    ],
    'database' => [
        'host'    => '127.0.0.1',
        'dbname'  => 'mobilefix',
        'username' => 'root',
        'password' => '00000000',
        'charset' => 'utf8mb4',
    ],
];
