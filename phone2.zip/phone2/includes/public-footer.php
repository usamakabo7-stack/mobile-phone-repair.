<?php
// ============================================================
// MobileFix - Public page footer
// ============================================================
?>
</main>
<footer style="text-align:center;padding:26px 16px;color:#9CA3AF;font-size:0.8rem;border-top:1px solid #E5EAF3;">
  &copy; <?php echo date('Y'); ?> MobileFix · Online Mobile Repair Management System
</footer>
<script src="assets/js/app.js"></script>
</body>
</html>
