<?php
// ============================================================
// MobileFix - CSRF protection
// ============================================================

function csrf_token()
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field()
{
    return '<input type="hidden" name="csrf_token" value="' . csrf_token() . '">';
}

function verify_csrf()
{
    $token = isset($_POST['csrf_token']) ? (string)$_POST['csrf_token'] : '';
    $expected = isset($_SESSION['csrf_token']) ? (string)$_SESSION['csrf_token'] : '';
    if ($expected === '' || !hash_equals($expected, $token)) {
        http_response_code(400);
        die('<div style="font-family:sans-serif;max-width:480px;margin:80px auto;padding:24px;border:1px solid #fecaca;border-radius:12px;background:#FEF2F2">
             <h3 style="color:#991B1B;margin:0 0 8px">Invalid security token</h3>
             <p style="color:#7F1D1D">Your request was rejected because the page was open for too long or the form was tampered with. Please go back, refresh the page, and try again.</p>
             <a href="javascript:history.back()" style="display:inline-block;margin-top:10px;background:#071A45;color:#fff;padding:8px 18px;border-radius:60px;text-decoration:none;font-weight:700">Go back</a>
             </div>');
    }
}
