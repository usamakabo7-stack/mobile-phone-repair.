<?php
// ============================================================
// MobileFix - Dashboard layout header (sidebar + topbar)
// Expects: $page_title, $active (already set by the page)
// ============================================================
require_once __DIR__ . '/auth.php';

$pageTitle = isset($page_title) ? $page_title : 'Dashboard';
$active    = isset($active) ? $active : '';
$role      = current_role();
$user      = isset($_SESSION['user']) ? $_SESSION['user'] : ['name' => 'User', 'role' => $role];
$navLinks  = sidebar_links($role);
$roleLabel = $role === 'technician' ? 'Technician' : ($role === 'admin' ? 'Administrator' : 'Customer');
$initial   = strtoupper(substr(trim($user['name']), 0, 1));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo e($pageTitle); ?> · MobileFix</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="stylesheet" href="../assets/css/app.css">
</head>
<body>
<div class="dash-shell">

  <aside class="sidebar" id="sidebar">
    <div class="sidebar-brand">
      <div class="logo-icon"><i class="fas fa-mobile-alt"></i></div>
      <div class="logo-text">
        <div class="brand"><span>Mobile</span><span>Fix</span></div>
        <div class="sub">Repair Management</div>
      </div>
    </div>
    <nav class="sidebar-nav">
      <?php foreach ($navLinks as $link): ?>
        <a href="<?php echo e($link[0]); ?>" class="<?php echo ($active === $link[1]) ? 'active' : ''; ?>">
          <i class="<?php echo e($link[2]); ?>"></i> <?php echo e($link[1]); ?>
        </a>
      <?php endforeach; ?>
    </nav>
    <div class="sidebar-foot">
      <a href="profile.php"><i class="fas fa-user-circle"></i> Profile</a>
      <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
  </aside>

  <div class="sidebar-overlay" id="sidebarOverlay"></div>

  <div class="dash-main">
    <header class="topbar">
      <div class="topbar-left">
        <button class="hamburger" id="hamburgerBtn" aria-label="Menu"><i class="fas fa-bars"></i></button>
        <div class="page-title"><?php echo e($pageTitle); ?></div>
      </div>
      <div class="user-chip">
        <div class="user-meta">
          <div class="name"><?php echo e($user['name']); ?></div>
          <div class="role"><?php echo e($roleLabel); ?></div>
        </div>
        <div class="user-avatar"><?php echo e($initial); ?></div>
        <a href="logout.php" title="Logout"><i class="fas fa-sign-out-alt"></i></a>
      </div>
    </header>
    <main class="dash-content">
      <?php render_flashes(); ?>
