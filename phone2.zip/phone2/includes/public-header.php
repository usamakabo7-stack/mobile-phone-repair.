<?php
// ============================================================
// MobileFix - Public page header (auth pages, tracking)
// Expects: $page_title
// ============================================================
require_once __DIR__ . '/auth.php';

$pageTitle = isset($page_title) ? $page_title : 'MobileFix';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo e($pageTitle); ?> · MobileFix</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="stylesheet" href="assets/css/app.css">
</head>
<body>
<div class="public-navbar">
  <div class="logo-area">
    <div class="logo-icon"><i class="fas fa-mobile-alt"></i></div>
    <div class="logo-text">
      <div class="brand"><span>Mobile</span><span>Fix</span></div>
      <div class="sub">Repair Management</div>
    </div>
  </div>
  <ul class="public-nav-links">
    <li><a href="index.php">Home</a></li>
    <li><a href="track-repair.php">Track Repair</a></li>
    <?php if (is_logged_in()): ?>
      <li><a href="<?php echo e(dashboard_for_role(current_role())); ?>">Dashboard</a></li>
    <?php else: ?>
      <li><a href="login.php">Login</a></li>
      <li><a href="register.php" class="active">Get Started</a></li>
    <?php endif; ?>
  </ul>
</div>
<main class="public-main">
