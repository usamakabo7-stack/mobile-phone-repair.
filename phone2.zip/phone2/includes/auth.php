<?php
// ============================================================
// MobileFix - Session handling & role-based access control
// ============================================================
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/csrf.php';

if (session_status() === PHP_SESSION_NONE) {
    session_name('MOBILEFIX_SESSION');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

/* ---------- Auth guards ---------- */
function require_login()
{
    if (empty($_SESSION['user_id'])) {
        flash('warning', 'Please log in to continue.');
        redirect('../login.php');
    }
}

function require_role(array $roles)
{
    require_login();
    if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], $roles, true)) {
        $destinations = [
            'customer'   => '../customer/dashboard.php',
            'technician' => '../technician/dashboard.php',
            'admin'      => '../admin/dashboard.php',
        ];
        redirect(isset($destinations[$_SESSION['role']]) ? $destinations[$_SESSION['role']] : '../login.php');
    }
}

function current_user_id()
{
    return isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null;
}

function current_role()
{
    return isset($_SESSION['role']) ? $_SESSION['role'] : null;
}

function is_logged_in()
{
    return !empty($_SESSION['user_id']);
}

/* Redirect a logged-in user to their own dashboard */
function dashboard_for_role($role)
{
    $map = [
        'customer'   => 'customer/dashboard.php',
        'technician' => 'technician/dashboard.php',
        'admin'      => 'admin/dashboard.php',
    ];
    return isset($map[$role]) ? $map[$role] : 'login.php';
}

/* ---------- Login helper ---------- */
function attempt_login(PDO $pdo, $email, $password)
{
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email LIMIT 1");
    $stmt->execute([':email' => trim($email)]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password'])) {
        return null;
    }

    if ($user['status'] !== 'active') {
        return 'inactive';
    }

    // Fresh, secure session for the authenticated user
    session_regenerate_id(true);
    $_SESSION['user_id']  = (int)$user['id'];
    $_SESSION['role']     = $user['role'];          // role always comes from the database
    $_SESSION['user']     = [
        'id'        => (int)$user['id'],
        'name'      => $user['full_name'],
        'email'     => $user['email'],
        'phone'     => $user['phone'],
        'role'      => $user['role'],
        'specialization' => $user['specialization'],
    ];

    return $user;
}

function logout()
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}

/* ---------- Shared validation helpers ---------- */
function validate_required(array $fields, array $source)
{
    $errors = [];
    foreach ($fields as $field => $label) {
        $value = isset($source[$field]) ? trim((string)$source[$field]) : '';
        if ($value === '') {
            $errors[] = $label . ' is required.';
        }
    }
    return $errors;
}
