<?php
// ============================================================
// MobileFix - Shared helper functions
// ============================================================
require_once __DIR__ . '/../config/database.php';

/* ---------- Output escaping ---------- */
function e($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/* ---------- Redirects & flash messages ---------- */
function redirect($url)
{
    header('Location: ' . $url);
    exit;
}

function flash($type, $message)
{
    if (!isset($_SESSION['flash'])) {
        $_SESSION['flash'] = [];
    }
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function get_flashes()
{
    $flashes = isset($_SESSION['flash']) ? $_SESSION['flash'] : [];
    unset($_SESSION['flash']);
    return $flashes;
}

function render_flashes()
{
    foreach (get_flashes() as $flash) {
        $type = in_array($flash['type'], ['success', 'error', 'warning', 'info'], true) ? $flash['type'] : 'info';
        echo '<div class="alert alert-' . $type . '"><span>' . e($flash['message']) . '</span><button class="alert-close" type="button" aria-label="Dismiss">&times;</button></div>';
    }
}

/* ---------- Money & dates ---------- */
function format_money($amount)
{
    $amount = (float)$amount;
    $decimals = (floor($amount) == $amount) ? 0 : 2;
    return '₦' . number_format($amount, $decimals);
}

function format_date($datetime, $format = 'd M Y')
{
    if (!$datetime) {
        return '—';
    }
    $ts = strtotime($datetime);
    return $ts ? date($format, $ts) : '—';
}

function format_datetime($datetime)
{
    if (!$datetime) {
        return '—';
    }
    $ts = strtotime($datetime);
    return $ts ? date('d M Y, h:i A', $ts) : '—';
}

/* ---------- Reference generators ---------- */
function next_reference(PDO $pdo, $prefix, $table, $column)
{
    $year = date('Y');
    $like = $prefix . $year . '-%';
    $stmt = $pdo->prepare("SELECT {$column} FROM {$table} WHERE {$column} LIKE ? ORDER BY id DESC LIMIT 1");
    $stmt->execute([$like]);
    $last = $stmt->fetchColumn();

    if ($last) {
        $num = (int)substr($last, strrpos($last, '-') + 1) + 1;
    } else {
        $num = 1;
    }

    return $prefix . $year . '-' . str_pad($num, 4, '0', STR_PAD_LEFT);
}

function next_repair_reference(PDO $pdo)
{
    return next_reference($pdo, 'MR-', 'repair_requests', 'reference');
}

function next_invoice_reference(PDO $pdo)
{
    return next_reference($pdo, 'INV-', 'invoices', 'invoice_no');
}

/* ---------- Status badge helpers ---------- */
function status_class($status)
{
    $map = [
        'Pending'    => 'gray',
        'Assigned'   => 'blue',
        'Diagnosing' => 'purple',
        'Repairing'  => 'yellow',
        'Completed'  => 'green',
        'Collected'  => 'dark',
        'Cancelled'  => 'red',
    ];
    return isset($map[$status]) ? 'badge-' . $map[$status] : 'badge-gray';
}

function badge_color($status)
{
    $map = [
        'Pending'    => '#6B7280',
        'Assigned'   => '#2563EB',
        'Diagnosing' => '#7C3AED',
        'Repairing'  => '#FFC400',
        'Completed'  => '#16A34A',
        'Collected'  => '#111827',
        'Cancelled'  => '#DC2626',
    ];
    return isset($map[$status]) ? $map[$status] : '#6B7280';
}

function status_badge($status)
{
    return '<span class="badge ' . status_class($status) . '">' . e($status) . '</span>';
}

function payment_badge($status)
{
    $class = (strtolower($status) === 'paid') ? 'badge-green' : 'badge-red';
    return '<span class="badge ' . $class . '">' . e($status) . '</span>';
}

/* ---------- Repair status flow ---------- */
function status_flow()
{
    return ['Pending', 'Assigned', 'Diagnosing', 'Repairing', 'Completed', 'Collected'];
}

function status_index($status)
{
    $flow = array_flip(status_flow());
    return isset($flow[$status]) ? $flow[$status] : 0;
}

/* Allowed forward statuses a technician can move a repair to */
function technician_next_statuses($status)
{
    $map = [
        'Assigned'   => ['Diagnosing'],
        'Diagnosing' => ['Repairing'],
        'Repairing'  => ['Completed'],
    ];
    return isset($map[$status]) ? $map[$status] : [];
}

function can_cancel($status)
{
    return in_array($status, ['Pending', 'Assigned', 'Diagnosing', 'Repairing'], true);
}

function is_open($status)
{
    return in_array($status, ['Pending', 'Assigned', 'Diagnosing', 'Repairing'], true);
}

/* ---------- Repair helpers ---------- */
function get_repair(PDO $pdo, $id)
{
    $stmt = $pdo->prepare(
        "SELECT r.*, u.full_name AS customer_name, u.phone AS customer_phone, u.email AS customer_email,
                t.full_name AS technician_name
         FROM repair_requests r
         JOIN users u ON u.id = r.customer_id
         LEFT JOIN users t ON t.id = r.technician_id
         WHERE r.id = :id"
    );
    $stmt->execute([':id' => (int)$id]);
    return $stmt->fetch();
}

function get_repair_by_reference(PDO $pdo, $reference)
{
    $stmt = $pdo->prepare(
        "SELECT r.*, u.full_name AS customer_name, u.phone AS customer_phone,
                t.full_name AS technician_name
         FROM repair_requests r
         JOIN users u ON u.id = r.customer_id
         LEFT JOIN users t ON t.id = r.technician_id
         WHERE r.reference = :ref"
    );
    $stmt->execute([':ref' => $reference]);
    return $stmt->fetch();
}

function get_repair_parts(PDO $pdo, $repairId)
{
    $stmt = $pdo->prepare("SELECT * FROM repair_parts WHERE repair_id = :id ORDER BY id");
    $stmt->execute([':id' => (int)$repairId]);
    return $stmt->fetchAll();
}

function parts_cost_for_repair(PDO $pdo, $repairId)
{
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(subtotal),0) FROM repair_parts WHERE repair_id = :id");
    $stmt->execute([':id' => (int)$repairId]);
    return (float)$stmt->fetchColumn();
}

function get_invoice_for_repair(PDO $pdo, $repairId)
{
    $stmt = $pdo->prepare("SELECT * FROM invoices WHERE repair_id = :id");
    $stmt->execute([':id' => (int)$repairId]);
    return $stmt->fetch();
}

function get_history(PDO $pdo, $repairId)
{
    $stmt = $pdo->prepare(
        "SELECT h.*, u.full_name AS actor
         FROM repair_status_history h
         LEFT JOIN users u ON u.id = h.created_by
         WHERE h.repair_id = :id ORDER BY h.created_at ASC, h.id ASC"
    );
    $stmt->execute([':id' => (int)$repairId]);
    return $stmt->fetchAll();
}

/* Record a status change in history */
function log_status(PDO $pdo, $repairId, $status, $note = null, $userId = null)
{
    $stmt = $pdo->prepare(
        "INSERT INTO repair_status_history (repair_id, status, note, created_by)
         VALUES (:rid, :status, :note, :by)"
    );
    $stmt->execute([
        ':rid'    => (int)$repairId,
        ':status' => $status,
        ':note'   => $note,
        ':by'     => $userId ? (int)$userId : null,
    ]);
}

/* Build an attractive vertical timeline from the standard flow + history */
function repair_timeline(array $history, $currentStatus)
{
    $flow = status_flow();
    $idx = status_index($currentStatus);

    $firstByStatus = [];
    foreach ($history as $entry) {
        if (!isset($firstByStatus[$entry['status']])) {
            $firstByStatus[$entry['status']] = $entry;
        }
    }

    $html = '<ol class="timeline">';

    if ($currentStatus === 'Cancelled') {
        // Show all steps up to the point of cancellation as done, plus a red cancelled step
        $lastNormal = null;
        foreach ($history as $entry) {
            if ($entry['status'] !== 'Cancelled') {
                $lastNormal = $entry['status'];
            }
        }
        $doneIdx = $lastNormal ? status_index($lastNormal) : 0;
        foreach ($flow as $i => $step) {
            $state = ($i < $doneIdx || ($doneIdx > 0 && $i === $doneIdx)) ? 'done' : 'future';
            $entry = isset($firstByStatus[$step]) ? $firstByStatus[$step] : null;
            $html .= timeline_step($step, $state, $entry);
        }
        // cancelled marker
        $cancelEntry = null;
        foreach ($history as $entry) {
            if ($entry['status'] === 'Cancelled') {
                $cancelEntry = $entry;
            }
        }
        $html .= '<li class="timeline-step cancelled">'
               . '<span class="t-line"></span>'
               . '<span class="t-dot"><i class="fas fa-times"></i></span>'
               . '<div class="t-body"><div class="t-title">Repair Cancelled</div>'
               . '<div class="t-time">' . e(format_datetime($cancelEntry ? $cancelEntry['created_at'] : date('Y-m-d H:i:s'))) . '</div>'
               . ($cancelEntry && $cancelEntry['note'] ? '<div class="t-note">' . e($cancelEntry['note']) . '</div>' : '')
               . '</div></li>';
        $html .= '</ol>';
        return $html;
    }

    foreach ($flow as $i => $step) {
        $state = 'future';
        if ($i < $idx) {
            $state = 'done';
        } elseif ($i === $idx) {
            $state = 'current';
        }
        $entry = isset($firstByStatus[$step]) ? $firstByStatus[$step] : null;
        $html .= timeline_step($step, $state, $entry);
    }

    $html .= '</ol>';
    return $html;
}

function timeline_step($status, $state, $entry = null)
{
    $icon = '<i class="fas fa-check"></i>';
    if ($state === 'current') {
        $icon = '<span class="t-spinner"></span>';
    } elseif ($state === 'future') {
        $icon = '<i class="far fa-circle"></i>';
    }

    $time = $entry ? format_datetime($entry['created_at']) : '';
    $note = '';
    if ($entry && !empty($entry['note'])) {
        $note = '<div class="t-note">' . e($entry['note']) . '</div>';
    }

    return '<li class="timeline-step ' . $state . '">'
         . '<span class="t-line"></span>'
         . '<span class="t-dot">' . $icon . '</span>'
         . '<div class="t-body">'
         . '<div class="t-title">' . e($status) . '</div>'
         . ($time ? '<div class="t-time">' . $time . '</div>' : '')
         . $note
         . '</div></li>';
}

/* ---------- Invoice sync (create or refresh) ---------- */
function sync_invoice(PDO $pdo, $repair)
{
    if (!$repair) {
        return null;
    }
    $repairId   = (int)$repair['id'];
    $service    = (float)$repair['service_cost'];
    $partsCost  = parts_cost_for_repair($pdo, $repairId);
    $total      = $service + $partsCost;

    // Only bill a repair that actually has costs (or is already billed)
    $existing = get_invoice_for_repair($pdo, $repairId);

    if ($total <= 0 && !$existing) {
        return null;
    }

    if (!$existing) {
        $invoiceNo = next_invoice_reference($pdo);
        $stmt = $pdo->prepare(
            "INSERT INTO invoices (invoice_no, repair_id, customer_id, service_cost, parts_cost, total, payment_status)
             VALUES (:no, :rid, :cid, :svc, :parts, :total, 'Unpaid')"
        );
        $stmt->execute([
            ':no'    => $invoiceNo,
            ':rid'   => $repairId,
            ':cid'   => (int)$repair['customer_id'],
            ':svc'   => $service,
            ':parts' => $partsCost,
            ':total' => $total,
        ]);
        $invoiceId = (int)$pdo->lastInsertId();
    } else {
        $invoiceId = (int)$existing['id'];
        $stmt = $pdo->prepare(
            "UPDATE invoices SET service_cost = :svc, parts_cost = :parts, total = :total, payment_status = 'Unpaid'
             WHERE id = :id"
        );
        $stmt->execute([
            ':svc'   => $service,
            ':parts' => $partsCost,
            ':total' => $total,
            ':id'    => $invoiceId,
        ]);
        // Refresh line items
        $pdo->prepare("DELETE FROM invoice_items WHERE invoice_id = :id")->execute([':id' => $invoiceId]);
    }

    // Write line items: service charge + each part
    $parts = get_repair_parts($pdo, $repairId);

    if ($service > 0) {
        $stmt = $pdo->prepare(
            "INSERT INTO invoice_items (invoice_id, repair_id, description, quantity, unit_price, amount)
             VALUES (:inv, :rid, 'Repair service (labour)', 1, :price, :amount)"
        );
        $stmt->execute([':inv' => $invoiceId, ':rid' => $repairId, ':price' => $service, ':amount' => $service]);
    }

    $stmt = $pdo->prepare(
        "INSERT INTO invoice_items (invoice_id, repair_id, description, quantity, unit_price, amount)
         VALUES (:inv, :rid, :desc, :qty, :price, :amount)"
    );
    foreach ($parts as $part) {
        $stmt->execute([
            ':inv'    => $invoiceId,
            ':rid'    => $repairId,
            ':desc'   => $part['part_name'],
            ':qty'    => (int)$part['quantity'],
            ':price'  => (float)$part['unit_price'],
            ':amount' => (float)$part['subtotal'],
        ]);
    }

    return get_invoice_for_repair($pdo, $repairId);
}

/* Cancel a repair: restore any deducted stock and clear parts */
function cancel_repair(PDO $pdo, $repairId, $userId = null)
{
    $pdo->beginTransaction();
    try {
        $parts = get_repair_parts($pdo, $repairId);
        $restore = $pdo->prepare(
            "UPDATE inventory SET quantity = quantity + :qty WHERE id = :id"
        );
        foreach ($parts as $part) {
            if ($part['inventory_id']) {
                $restore->execute([':qty' => (int)$part['quantity'], ':id' => (int)$part['inventory_id']]);
            }
        }
        $pdo->prepare("DELETE FROM repair_parts WHERE repair_id = :id")->execute([':id' => (int)$repairId]);

        $stmt = $pdo->prepare(
            "UPDATE repair_requests SET status = 'Cancelled', service_cost = 0 WHERE id = :id"
        );
        $stmt->execute([':id' => (int)$repairId]);

        log_status($pdo, $repairId, 'Cancelled', 'Repair request cancelled.', $userId);

        $pdo->commit();
        return true;
    } catch (Exception $ex) {
        $pdo->rollBack();
        return false;
    }
}

/* ---------- Sidebar navigation ---------- */
function sidebar_links($role)
{
    $links = [
        'admin' => [
            ['dashboard.php', 'Dashboard', 'fas fa-th-large'],
            ['repairs.php', 'Repairs', 'fas fa-tools'],
            ['customers.php', 'Customers', 'fas fa-users'],
            ['technicians.php', 'Technicians', 'fas fa-user-cog'],
            ['inventory.php', 'Inventory', 'fas fa-boxes'],
            ['invoices.php', 'Invoices', 'fas fa-file-invoice'],
            ['reports.php', 'Reports', 'fas fa-chart-bar'],
        ],
        'technician' => [
            ['dashboard.php', 'Dashboard', 'fas fa-th-large'],
            ['repairs.php', 'My Repairs', 'fas fa-tools'],
        ],
        'customer' => [
            ['dashboard.php', 'Dashboard', 'fas fa-th-large'],
            ['repairs.php', 'My Repairs', 'fas fa-tools'],
            ['repair-request.php', 'Submit Repair', 'fas fa-plus-circle'],
            ['invoice.php', 'Invoices', 'fas fa-file-invoice'],
        ],
    ];
    return isset($links[$role]) ? $links[$role] : [];
}

/* ---------- Small UI helpers ---------- */
function empty_state($icon, $title, $subtitle = '')
{
    return '<div class="empty-state"><i class="' . e($icon) . '"></i>'
         . '<h3>' . e($title) . '</h3>'
         . ($subtitle ? '<p>' . e($subtitle) . '</p>' : '')
         . '</div>';
}

function plural($count, $singular, $plural = null)
{
    if ($plural === null) {
        $plural = $singular . 's';
    }
    return $count . ' ' . (($count == 1) ? $singular : $plural);
}
