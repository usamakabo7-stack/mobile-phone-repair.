<?php
// ============================================================
// MobileFix - Dashboard layout footer
// ============================================================
?>
    </main>
    <footer class="dash-footer">
      &copy; <?php echo date('Y'); ?> MobileFix · Online Mobile Repair Management System
    </footer>
  </div>
</div>
<script src="../assets/js/app.js"></script>
</body>
</html>
