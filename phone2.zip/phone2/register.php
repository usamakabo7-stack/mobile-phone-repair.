<?php
require_once __DIR__ . '/includes/auth.php';

if (is_logged_in()) {
    redirect(dashboard_for_role(current_role()));
}

$errors = [];
$input  = ['full_name' => '', 'phone' => '', 'email' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $input['full_name'] = isset($_POST['full_name']) ? trim($_POST['full_name']) : '';
    $input['phone']     = isset($_POST['phone']) ? trim($_POST['phone']) : '';
    $input['email']     = isset($_POST['email']) ? strtolower(trim($_POST['email'])) : '';
    $password           = isset($_POST['password']) ? $_POST['password'] : '';
    $confirm            = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';

    if ($input['full_name'] === '') {
        $errors[] = 'Full name is required.';
    } elseif (strlen($input['full_name']) < 3) {
        $errors[] = 'Full name must be at least 3 characters.';
    }

    if ($input['phone'] === '') {
        $errors[] = 'Phone number is required.';
    } elseif (!preg_match('/^[0-9+()\-\s]{7,20}$/', $input['phone'])) {
        $errors[] = 'Please enter a valid phone number.';
    }

    if ($input['email'] === '') {
        $errors[] = 'Email address is required.';
    } elseif (!filter_var($input['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }

    if (strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters.';
    } elseif ($password !== $confirm) {
        $errors[] = 'Passwords do not match.';
    }

    if (!$errors) {
        $stmt = db()->prepare("SELECT id FROM users WHERE email = :email LIMIT 1");
        $stmt->execute([':email' => $input['email']]);
        if ($stmt->fetch()) {
            $errors[] = 'An account with this email already exists. Please log in.';
        }
    }

    if (!$errors) {
        $stmt = db()->prepare(
            "INSERT INTO users (full_name, phone, email, password, role, status)
             VALUES (:name, :phone, :email, :pass, 'customer', 'active')"
        );
        $stmt->execute([
            ':name'  => $input['full_name'],
            ':phone' => $input['phone'],
            ':email' => $input['email'],
            ':pass'  => password_hash($password, PASSWORD_DEFAULT),
        ]);

        flash('success', 'Registration successful! Please log in to continue.');
        redirect('login.php');
    }
}

$page_title = 'Create Account';
require_once __DIR__ . '/includes/public-header.php';
?>
<div class="auth-card wide">
  <h1 class="auth-title">Create your account</h1>
  <p class="auth-sub">Join MobileFix to submit repair requests and track your devices.</p>

  <?php foreach ($errors as $error): ?>
    <div class="alert alert-error"><span><?php echo e($error); ?></span></div>
  <?php endforeach; ?>
  <?php render_flashes(); ?>

  <form method="post" action="register.php" novalidate class="js-validate">
    <?php echo csrf_field(); ?>
    <div class="form-row">
      <div class="form-group">
        <label for="full_name">Full Name <span class="req">*</span></label>
        <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo e($input['full_name']); ?>" required autocomplete="name">
      </div>
      <div class="form-group">
        <label for="phone">Phone Number <span class="req">*</span></label>
        <input type="tel" class="form-control" id="phone" name="phone" value="<?php echo e($input['phone']); ?>" required autocomplete="tel">
      </div>
    </div>
    <div class="form-group">
      <label for="email">Email Address <span class="req">*</span></label>
      <input type="email" class="form-control" id="email" name="email" value="<?php echo e($input['email']); ?>" required autocomplete="email">
      <div class="form-hint">Used to log in to your account.</div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label for="password">Password <span class="req">*</span></label>
        <div class="input-group">
          <input type="password" class="form-control" id="password" name="password" minlength="6" required autocomplete="new-password">
          <button type="button" class="input-icon password-toggle" aria-label="Show password" title="Show password"><i class="fas fa-eye"></i></button>
        </div>
        <div class="form-hint">At least 6 characters.</div>
      </div>
      <div class="form-group">
        <label for="confirm_password">Confirm Password <span class="req">*</span></label>
        <div class="input-group">
          <input type="password" class="form-control" id="confirm_password" name="confirm_password" required autocomplete="new-password">
          <button type="button" class="input-icon password-toggle" aria-label="Show password" title="Show password"><i class="fas fa-eye"></i></button>
        </div>
      </div>
    </div>
    <button type="submit" class="btn btn-primary btn-block" data-loading="Creating account..."><i class="fas fa-user-plus"></i> Create Account</button>
  </form>

  <div class="auth-foot">
    Already have an account? <a href="login.php">Log in</a>
  </div>
</div>
<?php require_once __DIR__ . '/includes/public-footer.php'; ?>
