<?php
require_once __DIR__ . '/includes/auth.php';

$repair    = null;
$searched  = false;
$notFound  = false;
$refInput  = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $refInput = isset($_POST['reference']) ? trim($_POST['reference']) : '';
} elseif (isset($_GET['ref'])) {
    $refInput = trim($_GET['ref']);
}

if ($refInput !== '') {
    $searched = true;
    $repair   = get_repair_by_reference(db(), $refInput);
    if (!$repair) {
        $notFound = true;
    } else {
        $repair['history'] = get_history(db(), $repair['id']);
        $repair['invoice'] = get_invoice_for_repair(db(), $repair['id']);
    }
}

$page_title = 'Track Repair';
require_once __DIR__ . '/includes/public-header.php';
?>
<div class="auth-card wide">
  <h1 class="auth-title">Track your repair</h1>
  <p class="auth-sub">Enter the repair reference number you received when you submitted your request.</p>

  <?php if ($searched && $notFound): ?>
    <div class="alert alert-error"><span>No repair found with that reference. Please check the number and try again.</span></div>
  <?php endif; ?>

  <form method="post" action="track-repair.php" novalidate>
    <?php echo csrf_field(); ?>
    <div class="form-row" style="grid-template-columns: 1fr auto;">
      <div class="form-group" style="margin-bottom:0;">
        <label for="reference">Repair Reference</label>
        <input type="text" class="form-control" id="reference" name="reference"
               placeholder="e.g. MR-2026-0001" value="<?php echo e($refInput); ?>" required>
      </div>
      <button type="submit" class="btn btn-primary mt-2" style="align-self:end;"><i class="fas fa-search"></i> Track</button>
    </div>
  </form>

  <?php if ($repair): ?>
    <div class="card mt-4" style="margin-bottom:0;">
      <div class="card-header">
        <div class="card-title"><?php echo e($repair['reference']); ?></div>
        <?php echo status_badge($repair['status']); ?>
      </div>
      <div class="card-body">
        <div class="meta-list mb-3">
          <div class="meta-item">
            <div class="m-label">Device</div>
            <div class="m-value"><?php echo e($repair['brand']) . ' ' . e($repair['model']); ?></div>
          </div>
          <div class="meta-item">
            <div class="m-label">Problem Type</div>
            <div class="m-value"><?php echo e($repair['problem_type']); ?></div>
          </div>
          <div class="meta-item">
            <div class="m-label">Submitted</div>
            <div class="m-value"><?php echo e(format_datetime($repair['created_at'])); ?></div>
          </div>
          <?php if ($repair['technician_name']): ?>
            <div class="meta-item">
              <div class="m-label">Assigned Technician</div>
              <div class="m-value"><?php echo e($repair['technician_name']); ?></div>
            </div>
          <?php endif; ?>
        </div>

        <?php if ($repair['description']): ?>
          <p class="muted small" style="margin-bottom:16px;"><strong>Reported problem:</strong> <?php echo e($repair['description']); ?></p>
        <?php endif; ?>

        <?php echo repair_timeline($repair['history'], $repair['status']); ?>

        <?php if ($repair['diagnosis']): ?>
          <hr class="divider">
          <div class="meta-item">
            <div class="m-label">Diagnosis</div>
            <div class="m-value small"><?php echo e($repair['diagnosis']); ?></div>
          </div>
        <?php endif; ?>
        <?php if ($repair['repair_notes']): ?>
          <div class="meta-item mt-2">
            <div class="m-label">Repair Notes</div>
            <div class="m-value small"><?php echo e($repair['repair_notes']); ?></div>
          </div>
        <?php endif; ?>
      </div>
    </div>
  <?php endif; ?>
</div>
<?php require_once __DIR__ . '/includes/public-footer.php'; ?>
