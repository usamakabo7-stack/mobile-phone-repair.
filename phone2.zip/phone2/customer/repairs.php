<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['customer']);

$pdo = db();
$uid = current_user_id();

$stmt = $pdo->prepare(
    "SELECT r.*, i.invoice_no, i.total AS invoice_total, i.payment_status
     FROM repair_requests r
     LEFT JOIN invoices i ON i.repair_id = r.id
     WHERE r.customer_id = :uid
     ORDER BY r.created_at DESC"
);
$stmt->execute([':uid' => $uid]);
$repairs = $stmt->fetchAll();

$page_title = 'My Repairs';
$active = 'My Repairs';
require_once __DIR__ . '/../includes/dash-header.php';
?>

<div class="page-head">
  <div>
    <h1>My Repairs</h1>
    <p>All your repair requests, from submission to collection.</p>
  </div>
  <a href="repair-request.php" class="btn btn-primary"><i class="fas fa-plus-circle"></i> Submit Repair</a>
</div>

<div class="card">
  <div class="card-header">
    <div class="card-title">Repair History</div>
    <div class="search-box">
      <i class="fas fa-search"></i>
      <input type="text" class="form-control" placeholder="Search repairs..." data-target="#repairsTable">
    </div>
  </div>
  <?php if ($repairs): ?>
    <div class="table-wrap">
      <table class="table" id="repairsTable">
        <thead>
          <tr>
            <th>Reference</th>
            <th>Device</th>
            <th>Problem</th>
            <th>Status</th>
            <th>Amount</th>
            <th>Payment</th>
            <th>Date</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($repairs as $repair): ?>
            <tr>
              <td><strong><?php echo e($repair['reference']); ?></strong></td>
              <td><?php echo e($repair['brand'] . ' ' . $repair['model']); ?></td>
              <td class="table-muted"><?php echo e($repair['problem_type']); ?></td>
              <td><?php echo status_badge($repair['status']); ?></td>
              <td><?php echo $repair['invoice_no'] ? format_money($repair['invoice_total']) : '—'; ?></td>
              <td><?php echo $repair['invoice_no'] ? payment_badge($repair['payment_status']) : '—'; ?></td>
              <td class="table-muted"><?php echo e(format_date($repair['created_at'])); ?></td>
              <td>
                <div class="table-actions">
                  <a href="repair-view.php?id=<?php echo (int)$repair['id']; ?>" class="btn btn-outline btn-xs">View</a>
                  <?php if ($repair['invoice_no']): ?>
                    <a href="invoice.php?repair=<?php echo (int)$repair['id']; ?>" class="btn btn-ghost btn-xs">Invoice</a>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <?php echo empty_state('fas fa-tools', 'No repairs yet', 'Submit your first repair request to get started.'); ?>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
