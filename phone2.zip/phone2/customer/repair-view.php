<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['customer']);

$pdo = db();
$uid = current_user_id();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$stmt = $pdo->prepare("SELECT * FROM repair_requests WHERE id = :id AND customer_id = :uid LIMIT 1");
$stmt->execute([':id' => $id, ':uid' => $uid]);
$repair = $stmt->fetch();

if (!$repair) {
    flash('error', 'Repair not found or you do not have permission to view it.');
    redirect('repairs.php');
}

$history = get_history($pdo, $repair['id']);
$parts   = get_repair_parts($pdo, $repair['id']);
$invoice = get_invoice_for_repair($pdo, $repair['id']);

$stmt = $pdo->prepare("SELECT full_name, phone, specialization FROM users WHERE id = :id");
$stmt->execute([':id' => $repair['technician_id']]);
$technician = $stmt->fetch();

$page_title = $repair['reference'];
$active = 'My Repairs';
require_once __DIR__ . '/../includes/dash-header.php';
?>

<div class="page-head">
  <div>
    <h1><?php echo e($repair['reference']); ?></h1>
    <p>Submitted on <?php echo e(format_datetime($repair['created_at'])); ?></p>
  </div>
  <?php echo status_badge($repair['status']); ?>
</div>

<div class="grid-2">
  <div>
    <div class="card">
      <div class="card-header"><div class="card-title">Device &amp; Problem</div></div>
      <div class="card-body">
        <div class="meta-list">
          <div class="meta-item">
            <div class="m-label">Device</div>
            <div class="m-value"><?php echo e($repair['brand'] . ' ' . $repair['model']); ?></div>
          </div>
          <div class="meta-item">
            <div class="m-label">Problem Type</div>
            <div class="m-value"><?php echo e($repair['problem_type']); ?></div>
          </div>
          <?php if ($repair['imei']): ?>
            <div class="meta-item">
              <div class="m-label">IMEI</div>
              <div class="m-value"><?php echo e($repair['imei']); ?></div>
            </div>
          <?php endif; ?>
          <?php if ($technician): ?>
            <div class="meta-item">
              <div class="m-label">Assigned Technician</div>
              <div class="m-value"><?php echo e($technician['full_name']); ?>
                <span class="small muted"><?php echo $technician['specialization'] ? '· ' . e($technician['specialization']) : ''; ?></span>
              </div>
            </div>
          <?php endif; ?>
        </div>
        <hr class="divider">
        <div class="m-label mb-1">Your Description</div>
        <p class="muted"><?php echo nl2br(e($repair['description'])); ?></p>

        <?php if ($repair['diagnosis']): ?>
          <hr class="divider">
          <div class="m-label mb-1">Diagnosis</div>
          <p class="muted"><?php echo nl2br(e($repair['diagnosis'])); ?></p>
        <?php endif; ?>

        <?php if ($repair['repair_notes']): ?>
          <hr class="divider">
          <div class="m-label mb-1">Repair Notes</div>
          <p class="muted"><?php echo nl2br(e($repair['repair_notes'])); ?></p>
        <?php endif; ?>
      </div>
    </div>

    <?php if ($invoice): ?>
      <div class="card">
        <div class="card-header">
          <div class="card-title">Cost Summary</div>
          <a href="invoice.php?repair=<?php echo (int)$repair['id']; ?>" class="btn btn-navy btn-sm">View Invoice</a>
        </div>
        <div class="card-body">
          <div class="meta-list">
            <div class="meta-item">
              <div class="m-label">Service / Labour</div>
              <div class="m-value"><?php echo format_money($invoice['service_cost']); ?></div>
            </div>
            <div class="meta-item">
              <div class="m-label">Parts</div>
              <div class="m-value"><?php echo format_money($invoice['parts_cost']); ?></div>
            </div>
            <div class="meta-item">
              <div class="m-label">Total</div>
              <div class="m-value"><?php echo format_money($invoice['total']); ?></div>
            </div>
            <div class="meta-item">
              <div class="m-label">Payment</div>
              <div class="m-value"><?php echo payment_badge($invoice['payment_status']); ?></div>
            </div>
          </div>
          <?php if ($parts): ?>
            <hr class="divider">
            <table class="table">
              <thead>
                <tr><th>Part</th><th>Qty</th><th class="text-right">Amount</th></tr>
              </thead>
              <tbody>
                <?php foreach ($parts as $part): ?>
                  <tr>
                    <td><?php echo e($part['part_name']); ?></td>
                    <td><?php echo (int)$part['quantity']; ?></td>
                    <td class="text-right"><?php echo format_money($part['subtotal']); ?></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          <?php endif; ?>
        </div>
      </div>
    <?php endif; ?>
  </div>

  <div>
    <div class="card">
      <div class="card-header"><div class="card-title">Repair Progress</div></div>
      <div class="card-body">
        <?php echo repair_timeline($history, $repair['status']); ?>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
