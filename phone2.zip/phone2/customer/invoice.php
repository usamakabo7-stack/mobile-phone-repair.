<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['customer']);

$pdo = db();
$uid = current_user_id();

/* ---------- Single invoice view ---------- */
$repairId = isset($_GET['repair']) ? (int)$_GET['repair'] : 0;

if ($repairId > 0) {
    // Ownership check: the repair must belong to this customer
    $stmt = $pdo->prepare("SELECT id FROM repair_requests WHERE id = :id AND customer_id = :uid LIMIT 1");
    $stmt->execute([':id' => $repairId, ':uid' => $uid]);
    if (!$stmt->fetch()) {
        flash('error', 'Invoice not found or you do not have permission to view it.');
        redirect('invoice.php');
    }

    $invoice = get_invoice_for_repair($pdo, $repairId);
    if (!$invoice) {
        flash('warning', 'No invoice has been generated for this repair yet.');
        redirect('repairs.php');
    }

    $stmt = $pdo->prepare(
        "SELECT r.*, u.full_name AS customer_name, u.phone AS customer_phone, u.email AS customer_email
         FROM repair_requests r
         JOIN users u ON u.id = r.customer_id
         WHERE r.id = :id"
    );
    $stmt->execute([':id' => $repairId]);
    $repair = $stmt->fetch();

    $stmt = $pdo->prepare("SELECT * FROM invoice_items WHERE invoice_id = :inv ORDER BY id");
    $stmt->execute([':inv' => $invoice['id']]);
    $items = $stmt->fetchAll();

    $page_title = $invoice['invoice_no'];
    $active = 'Invoices';
    require_once __DIR__ . '/../includes/dash-header.php';
    ?>

    <div class="page-head">
      <div>
        <h1>Invoice</h1>
        <p><?php echo e($invoice['invoice_no']); ?></p>
      </div>
      <div class="no-print form-actions">
        <a href="invoice.php" class="btn btn-outline"><i class="fas fa-arrow-left"></i> All Invoices</a>
        <button type="button" class="btn btn-navy" onclick="window.print()"><i class="fas fa-print"></i> Print Invoice</button>
      </div>
    </div>

    <div class="invoice-wrap">
      <div class="invoice">
        <div class="inv-head">
          <div>
            <div class="inv-brand"><span>Mobile</span><span>Fix</span></div>
            <div class="inv-brand-sub">Repair Management System</div>
          </div>
          <div class="inv-no">
            <?php echo e($invoice['invoice_no']); ?>
            <small><?php echo e($repair['reference']); ?> · <?php echo e(format_date($invoice['created_at'])); ?></small>
          </div>
        </div>

        <div class="inv-row">
          <div>
            <div class="inv-label">Billed To</div>
            <div class="inv-value"><?php echo e($repair['customer_name']); ?></div>
            <div class="small muted"><?php echo e($repair['customer_phone']); ?></div>
            <div class="small muted"><?php echo e($repair['customer_email']); ?></div>
          </div>
          <div>
            <div class="inv-label">Device</div>
            <div class="inv-value"><?php echo e($repair['brand'] . ' ' . $repair['model']); ?></div>
            <div class="small muted"><?php echo e($repair['problem_type']); ?></div>
            <div class="small muted">Status: <?php echo e($repair['status']); ?></div>
          </div>
        </div>

        <table class="inv-table">
          <thead>
            <tr><th>Description</th><th class="text-right">Qty</th><th class="text-right">Unit Price</th><th class="text-right">Amount</th></tr>
          </thead>
          <tbody>
            <?php foreach ($items as $item): ?>
              <tr>
                <td><?php echo e($item['description']); ?></td>
                <td class="num"><?php echo (int)$item['quantity']; ?></td>
                <td class="num"><?php echo format_money($item['unit_price']); ?></td>
                <td class="num"><?php echo format_money($item['amount']); ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>

        <div class="inv-totals">
          <div class="inv-total-line"><span>Service / Labour</span><span><?php echo format_money($invoice['service_cost']); ?></span></div>
          <div class="inv-total-line"><span>Parts</span><span><?php echo format_money($invoice['parts_cost']); ?></span></div>
          <div class="inv-total-line grand"><span>Total</span><span><?php echo format_money($invoice['total']); ?></span></div>
          <div class="inv-total-line"><span>Payment</span><span><?php echo payment_badge($invoice['payment_status']); ?></span></div>
        </div>

        <div class="inv-foot">
          Thank you for choosing MobileFix.<br>
          Device is ready for collection after payment at our service centre.
        </div>
      </div>
    </div>

    <?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
    <?php exit; ?>
<?php } ?>

<?php
/* ---------- Invoice list ---------- */
$stmt = $pdo->prepare(
    "SELECT i.*, r.reference, r.brand, r.model, r.status AS repair_status
     FROM invoices i
     JOIN repair_requests r ON r.id = i.repair_id
     WHERE i.customer_id = :uid
     ORDER BY i.created_at DESC"
);
$stmt->execute([':uid' => $uid]);
$invoices = $stmt->fetchAll();

$page_title = 'My Invoices';
$active = 'Invoices';
require_once __DIR__ . '/../includes/dash-header.php';
?>

<div class="page-head">
  <div>
    <h1>My Invoices</h1>
    <p>View and print invoices for your completed repairs.</p>
  </div>
</div>

<div class="card">
  <?php if ($invoices): ?>
    <div class="table-wrap">
      <table class="table">
        <thead>
          <tr>
            <th>Invoice No</th>
            <th>Repair</th>
            <th>Device</th>
            <th>Total</th>
            <th>Payment</th>
            <th>Date</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($invoices as $inv): ?>
            <tr>
              <td><strong><?php echo e($inv['invoice_no']); ?></strong></td>
              <td><?php echo e($inv['reference']); ?></td>
              <td><?php echo e($inv['brand'] . ' ' . $inv['model']); ?></td>
              <td><?php echo format_money($inv['total']); ?></td>
              <td><?php echo payment_badge($inv['payment_status']); ?></td>
              <td class="table-muted"><?php echo e(format_date($inv['created_at'])); ?></td>
              <td>
                <a href="invoice.php?repair=<?php echo (int)$inv['repair_id']; ?>" class="btn btn-outline btn-xs">
                  <i class="fas fa-file-invoice"></i> View
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <?php echo empty_state('fas fa-file-invoice', 'No invoices yet', 'Invoices appear here once a repair has been billed.'); ?>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
