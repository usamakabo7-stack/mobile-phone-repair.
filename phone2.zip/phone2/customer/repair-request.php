<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['customer']);

$pdo = db();
$uid = current_user_id();

$errors = [];
$input = [
    'brand'          => '',
    'model'          => '',
    'problem_type'   => '',
    'description'    => '',
    'imei'           => '',
];

$problemTypes = [
    'Broken Screen', 'Cracked Screen', 'Battery Replacement', 'Charging Port',
    'No Power / Will Not Boot', 'Software / Update Issue', 'Water Damage',
    'Speaker / Microphone', 'Camera Problem', 'Network / Signal', 'Other',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $input['brand']        = isset($_POST['brand']) ? trim($_POST['brand']) : '';
    $input['model']        = isset($_POST['model']) ? trim($_POST['model']) : '';
    $input['problem_type'] = isset($_POST['problem_type']) ? trim($_POST['problem_type']) : '';
    $input['description']  = isset($_POST['description']) ? trim($_POST['description']) : '';
    $input['imei']         = isset($_POST['imei']) ? trim($_POST['imei']) : '';

    if ($input['brand'] === '') {
        $errors[] = 'Device brand is required.';
    }
    if ($input['model'] === '') {
        $errors[] = 'Device model is required.';
    }
    if ($input['problem_type'] === '') {
        $errors[] = 'Problem type is required.';
    }
    if ($input['description'] === '') {
        $errors[] = 'Please describe the problem you are facing.';
    } elseif (strlen($input['description']) < 10) {
        $errors[] = 'Problem description must be at least 10 characters.';
    }
    if ($input['imei'] !== '' && !preg_match('/^[0-9A-Za-z\-]{10,20}$/', $input['imei'])) {
        $errors[] = 'IMEI must be 10–20 digits/letters.';
    }

    if (!$errors) {
        $reference = next_repair_reference($pdo);

        $stmt = $pdo->prepare(
            "INSERT INTO repair_requests (reference, customer_id, brand, model, problem_type, description, imei, status)
             VALUES (:ref, :cid, :brand, :model, :problem, :desc, :imei, 'Pending')"
        );
        $stmt->execute([
            ':ref'     => $reference,
            ':cid'     => $uid,
            ':brand'   => $input['brand'],
            ':model'   => $input['model'],
            ':problem' => $input['problem_type'],
            ':desc'    => $input['description'],
            ':imei'    => $input['imei'] !== '' ? $input['imei'] : null,
        ]);

        $repairId = (int)$pdo->lastInsertId();
        log_status($pdo, $repairId, 'Pending', 'Repair request submitted by customer.', $uid);

        flash('success', 'Repair request submitted successfully. Your reference number is <strong>' . $reference . '</strong>.');
        redirect('repair-view.php?id=' . $repairId);
    }
}

$page_title = 'Submit Repair Request';
$active = 'Submit Repair';
require_once __DIR__ . '/../includes/dash-header.php';
?>

<div class="page-head">
  <div>
    <h1>Submit a Repair Request</h1>
    <p>Tell us about your device and the problem you are facing.</p>
  </div>
</div>

<div class="card" style="max-width:760px;">
  <div class="card-body">
    <?php foreach ($errors as $error): ?>
      <div class="alert alert-error"><span><?php echo e($error); ?></span></div>
    <?php endforeach; ?>

    <form method="post" action="repair-request.php" novalidate class="js-validate">
      <?php echo csrf_field(); ?>
      <div class="form-row">
        <div class="form-group">
          <label for="brand">Device Brand <span class="req">*</span></label>
          <input type="text" class="form-control" id="brand" name="brand" placeholder="e.g. Samsung" value="<?php echo e($input['brand']); ?>" required>
        </div>
        <div class="form-group">
          <label for="model">Device Model <span class="req">*</span></label>
          <input type="text" class="form-control" id="model" name="model" placeholder="e.g. Galaxy A15" value="<?php echo e($input['model']); ?>" required>
        </div>
      </div>
      <div class="form-group">
        <label for="problem_type">Problem Type <span class="req">*</span></label>
        <select class="form-control" id="problem_type" name="problem_type" required>
          <option value="">-- Select a problem --</option>
          <?php foreach ($problemTypes as $pt): ?>
            <option value="<?php echo e($pt); ?>" <?php echo ($input['problem_type'] === $pt) ? 'selected' : ''; ?>><?php echo e($pt); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group">
        <label for="description">Problem Description <span class="req">*</span></label>
        <textarea class="form-control" id="description" name="description" placeholder="Describe what happened and what is wrong with the device." required><?php echo e($input['description']); ?></textarea>
      </div>
      <div class="form-group">
        <label for="imei">Device IMEI <span class="muted small">(optional)</span></label>
        <input type="text" class="form-control" id="imei" name="imei" placeholder="e.g. 352156071234567" value="<?php echo e($input['imei']); ?>">
        <div class="form-hint">You can find the IMEI by dialling *#06# on the phone.</div>
      </div>
      <div class="form-actions">
        <button type="submit" class="btn btn-primary" data-loading="Submitting..."><i class="fas fa-paper-plane"></i> Submit Request</button>
        <a href="dashboard.php" class="btn btn-outline">Cancel</a>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
