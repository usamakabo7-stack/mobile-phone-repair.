<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['customer']);

$pdo = db();
$uid = current_user_id();

// Status counts for this customer
$stmt = $pdo->prepare("SELECT status, COUNT(*) AS c FROM repair_requests WHERE customer_id = :uid GROUP BY status");
$stmt->execute([':uid' => $uid]);
$counts = [];
foreach ($stmt->fetchAll() as $row) {
    $counts[$row['status']] = (int)$row['c'];
}
$total = array_sum($counts);

// Latest active (open) repair
$stmt = $pdo->prepare(
    "SELECT * FROM repair_requests WHERE customer_id = :uid AND status IN ('Pending','Assigned','Diagnosing','Repairing')
     ORDER BY created_at DESC LIMIT 1"
);
$stmt->execute([':uid' => $uid]);
$activeRepair = $stmt->fetch();

// Recent repairs
$stmt = $pdo->prepare(
    "SELECT r.*, i.invoice_no, i.total AS invoice_total
     FROM repair_requests r
     LEFT JOIN invoices i ON i.repair_id = r.id
     WHERE r.customer_id = :uid
     ORDER BY r.created_at DESC LIMIT 6"
);
$stmt->execute([':uid' => $uid]);
$recentRepairs = $stmt->fetchAll();

$firstName = preg_replace('/\s+.*/', '', $_SESSION['user']['name']);

$page_title = 'Dashboard';
$active = 'Dashboard';
require_once __DIR__ . '/../includes/dash-header.php';
?>

<div class="page-head">
  <div>
    <h1>Welcome, <?php echo e($firstName); ?></h1>
    <p>Here is what is happening with your repairs.</p>
  </div>
  <a href="repair-request.php" class="btn btn-primary"><i class="fas fa-plus-circle"></i> Submit Repair</a>
</div>

<?php if ($activeRepair): ?>
  <div class="card" style="border-left:6px solid var(--yellow);">
    <div class="card-body">
      <div class="repair-card" style="box-shadow:none;border:none;padding:0;">
        <div class="repair-card-top">
          <div>
            <div class="small muted mb-1">Active Repair</div>
            <div class="repair-ref"><?php echo e($activeRepair['brand'] . ' ' . $activeRepair['model']); ?></div>
            <div class="small mt-1">
              Repair <strong>#<?php echo e($activeRepair['reference']); ?></strong>
            </div>
          </div>
          <?php echo status_badge($activeRepair['status']); ?>
        </div>
        <div class="card-actions">
          <a href="repair-view.php?id=<?php echo (int)$activeRepair['id']; ?>" class="btn btn-navy btn-sm"><i class="fas fa-search"></i> Track Repair</a>
        </div>
      </div>
    </div>
  </div>
<?php endif; ?>

<div class="stat-grid">
  <div class="stat-card">
    <div class="stat-icon"><i class="fas fa-hourglass-half"></i></div>
    <div>
      <div class="stat-value"><?php echo isset($counts['Pending']) ? $counts['Pending'] : 0; ?></div>
      <div class="stat-label">Pending</div>
    </div>
  </div>
  <div class="stat-card yellow">
    <div class="stat-icon"><i class="fas fa-tools"></i></div>
    <div>
      <div class="stat-value"><?php echo isset($counts['Repairing']) ? $counts['Repairing'] : 0; ?></div>
      <div class="stat-label">Repairing</div>
    </div>
  </div>
  <div class="stat-card green">
    <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
    <div>
      <div class="stat-value"><?php echo isset($counts['Completed']) ? $counts['Completed'] : 0; ?></div>
      <div class="stat-label">Completed</div>
    </div>
  </div>
  <div class="stat-card navy">
    <div class="stat-icon"><i class="fas fa-clipboard-list"></i></div>
    <div>
      <div class="stat-value"><?php echo $total; ?></div>
      <div class="stat-label">Total Repairs</div>
    </div>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <div class="card-title">My Repairs</div>
    <a href="repairs.php" class="btn btn-ghost btn-sm">View all <i class="fas fa-arrow-right"></i></a>
  </div>
  <?php if ($recentRepairs): ?>
    <div class="table-wrap">
      <table class="table">
        <thead>
          <tr>
            <th>Reference</th>
            <th>Device</th>
            <th>Status</th>
            <th>Date</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($recentRepairs as $repair): ?>
            <tr>
              <td><strong><?php echo e($repair['reference']); ?></strong></td>
              <td><?php echo e($repair['brand'] . ' ' . $repair['model']); ?></td>
              <td><?php echo status_badge($repair['status']); ?></td>
              <td class="table-muted"><?php echo e(format_date($repair['created_at'])); ?></td>
              <td>
                <div class="table-actions">
                  <a href="repair-view.php?id=<?php echo (int)$repair['id']; ?>" class="btn btn-outline btn-xs">View</a>
                  <?php if ($repair['invoice_no']): ?>
                    <a href="invoice.php?repair=<?php echo (int)$repair['id']; ?>" class="btn btn-ghost btn-xs">Invoice</a>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <?php echo empty_state('fas fa-tools', 'No repairs yet', 'Submit your first repair request to get started.'); ?>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
