<?php
// ============================================================
// MobileFix - Demo users seed (idempotent)
//
// Creates the three DEMONSTRATION accounts used by the
// final-year project presentation. Safe to run multiple times:
// accounts are only inserted when the email does not already
// exist. Passwords are hashed with password_hash().
//
// Run from the command line (from the project root):
//   php database/seed_demo_users.php
//
// Web access is intentionally blocked.
// ============================================================

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    die('This script can only be run from the command line.');
}

$config = require __DIR__ . '/../config/config.php';
$db = $config['database'];

$dsn = "mysql:host={$db['host']};dbname={$db['dbname']};charset={$db['charset']}";

try {
    $pdo = new PDO($dsn, $db['username'], $db['password'], [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    fwrite(STDERR, 'Could not connect to the database. Run install.php first: ' . $e->getMessage() . PHP_EOL);
    exit(1);
}

$users = [
    [
        'full_name'      => 'MobileFix Administrator',
        'phone'          => '08000000001',
        'email'          => 'admin@mobilefix.test',
        'password'       => 'Admin@12345',
        'role'           => 'admin',
        'specialization' => 'General',
    ],
    [
        'full_name'      => 'MobileFix Technician',
        'phone'          => '08000000002',
        'email'          => 'technician@mobilefix.test',
        'password'       => 'Tech@12345',
        'role'           => 'technician',
        'specialization' => 'Screen & Battery',
    ],
    [
        'full_name'      => 'Demo Customer',
        'phone'          => '08000000003',
        'email'          => 'customer@mobilefix.test',
        'password'       => 'Customer@12345',
        'role'           => 'customer',
        'specialization' => null,
    ],
];

$stmtCheck = $pdo->prepare("SELECT id FROM users WHERE email = :email LIMIT 1");
$stmtInsert = $pdo->prepare(
    "INSERT INTO users (full_name, phone, email, password, role, specialization, status)
     VALUES (:name, :phone, :email, :pass, :role, :spec, 'active')"
);

$created = 0;
$skipped = 0;

foreach ($users as $user) {
    $stmtCheck->execute([':email' => $user['email']]);
    if ($stmtCheck->fetchColumn()) {
        echo "SKIP  {$user['email']} (already exists)\n";
        $skipped++;
        continue;
    }
    $stmtInsert->execute([
        ':name'  => $user['full_name'],
        ':phone' => $user['phone'],
        ':email' => $user['email'],
        ':pass'  => password_hash($user['password'], PASSWORD_DEFAULT),
        ':role'  => $user['role'],
        ':spec'  => $user['specialization'],
    ]);
    echo "OK    {$user['email']} ({$user['role']})\n";
    $created++;
}

echo "\nDemo users seeded: {$created} created, {$skipped} already present.\n";
echo "See DEMO_LOGIN.md for the login details.\n";
