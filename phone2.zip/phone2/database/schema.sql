-- ============================================================
-- MobileFix - Online Mobile Repair Management System
-- Database Schema (MySQL / MariaDB)
-- ============================================================
-- To install: import this file with phpMyAdmin,
-- or open http://localhost/phone2/install.php in your browser.
-- ============================================================

CREATE DATABASE IF NOT EXISTS `mobilefix`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `mobilefix`;

-- ------------------------------------------------------------
-- USERS
-- One table holds all three roles (customer / technician / admin).
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `full_name` VARCHAR(120) NOT NULL,
  `phone` VARCHAR(20) DEFAULT NULL,
  `email` VARCHAR(120) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('customer','technician','admin') NOT NULL DEFAULT 'customer',
  `specialization` VARCHAR(120) DEFAULT NULL,
  `status` ENUM('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- INVENTORY (spare parts)
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `inventory`;
CREATE TABLE `inventory` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `part_name` VARCHAR(150) NOT NULL,
  `category` VARCHAR(80) DEFAULT NULL,
  `quantity` INT NOT NULL DEFAULT 0,
  `unit_price` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `min_stock` INT NOT NULL DEFAULT 0,
  `status` ENUM('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_inventory_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- REPAIR REQUESTS (the heart of the system)
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `repair_requests`;
CREATE TABLE `repair_requests` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `reference` VARCHAR(20) NOT NULL,
  `customer_id` INT UNSIGNED NOT NULL,
  `technician_id` INT UNSIGNED DEFAULT NULL,
  `brand` VARCHAR(80) NOT NULL,
  `model` VARCHAR(120) NOT NULL,
  `problem_type` VARCHAR(120) NOT NULL,
  `description` TEXT,
  `imei` VARCHAR(30) DEFAULT NULL,
  `status` ENUM('Pending','Assigned','Diagnosing','Repairing','Completed','Collected','Cancelled') NOT NULL DEFAULT 'Pending',
  `diagnosis` TEXT,
  `repair_notes` TEXT,
  `service_cost` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `completed_at` DATETIME DEFAULT NULL,
  `collected_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_repair_reference` (`reference`),
  KEY `idx_repair_customer` (`customer_id`),
  KEY `idx_repair_technician` (`technician_id`),
  KEY `idx_repair_status` (`status`),
  CONSTRAINT `fk_repair_customer` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_repair_technician` FOREIGN KEY (`technician_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- REPAIR PARTS (parts used on a specific repair)
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `repair_parts`;
CREATE TABLE `repair_parts` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `repair_id` INT UNSIGNED NOT NULL,
  `inventory_id` INT UNSIGNED DEFAULT NULL,
  `part_name` VARCHAR(150) NOT NULL,
  `quantity` INT NOT NULL DEFAULT 1,
  `unit_price` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `subtotal` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_repair_parts_repair` (`repair_id`),
  CONSTRAINT `fk_repair_parts_repair` FOREIGN KEY (`repair_id`) REFERENCES `repair_requests` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_repair_parts_inventory` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- INVOICES (one per repair, created when billing starts)
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `invoices`;
CREATE TABLE `invoices` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `invoice_no` VARCHAR(20) NOT NULL,
  `repair_id` INT UNSIGNED NOT NULL,
  `customer_id` INT UNSIGNED NOT NULL,
  `service_cost` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `parts_cost` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `total` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `payment_status` ENUM('Unpaid','Paid') NOT NULL DEFAULT 'Unpaid',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_invoice_no` (`invoice_no`),
  UNIQUE KEY `uq_invoice_repair` (`repair_id`),
  KEY `idx_invoice_customer` (`customer_id`),
  CONSTRAINT `fk_invoice_repair` FOREIGN KEY (`repair_id`) REFERENCES `repair_requests` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_invoice_customer` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- INVOICE ITEMS (service charge + each part line)
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `invoice_items`;
CREATE TABLE `invoice_items` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `invoice_id` INT UNSIGNED NOT NULL,
  `repair_id` INT UNSIGNED NOT NULL,
  `description` VARCHAR(200) NOT NULL,
  `quantity` INT NOT NULL DEFAULT 1,
  `unit_price` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `amount` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`),
  KEY `idx_invoice_items_invoice` (`invoice_id`),
  CONSTRAINT `fk_invoice_items_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_invoice_items_repair` FOREIGN KEY (`repair_id`) REFERENCES `repair_requests` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- REPAIR STATUS HISTORY (audit trail of every status change)
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `repair_status_history`;
CREATE TABLE `repair_status_history` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `repair_id` INT UNSIGNED NOT NULL,
  `status` VARCHAR(30) NOT NULL,
  `note` VARCHAR(255) DEFAULT NULL,
  `created_by` INT UNSIGNED DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_history_repair` (`repair_id`),
  CONSTRAINT `fk_history_repair` FOREIGN KEY (`repair_id`) REFERENCES `repair_requests` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_history_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- DEFAULT ADMIN ACCOUNT
-- Email:    admin@mobilefix.com
-- Password: admin123
-- ------------------------------------------------------------
INSERT INTO `users` (`full_name`, `phone`, `email`, `password`, `role`, `specialization`, `status`)
SELECT 'System Administrator', '08000000000', 'admin@mobilefix.com',
       '$2y$10$/gAq0ceDPhZ95CJZbRw86uVgq9A.ra943XZ6R1/j7oREX2gcOz0/i',
       'admin', 'General', 'active'
WHERE NOT EXISTS (
  SELECT 1 FROM `users` WHERE `email` = 'admin@mobilefix.com'
);
