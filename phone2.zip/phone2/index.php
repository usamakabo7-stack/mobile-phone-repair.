<?php
// MobileFix - public landing page
session_start();

$loggedIn = !empty($_SESSION['user_id']);
$role     = isset($_SESSION['role']) ? $_SESSION['role'] : '';
$dashMap  = ['customer' => 'customer/dashboard.php', 'technician' => 'technician/dashboard.php', 'admin' => 'admin/dashboard.php'];
$dashUrl  = ($loggedIn && isset($dashMap[$role])) ? $dashMap[$role] : 'register.php';
$submitUrl = ($loggedIn && $role === 'customer') ? 'customer/repair-request.php' : 'login.php';
$loginLabel = $loggedIn ? 'Dashboard' : 'Login';
$loginHref  = $loggedIn ? $dashUrl : 'login.php';
$startHref  = $loggedIn ? $dashUrl : 'register.php';
$startLabel = $loggedIn ? 'My Dashboard' : 'Get Started';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.5">
  <title>MobileFix · Repair Management</title>
  <!-- Google Fonts + Font Awesome -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: 'Plus Jakarta Sans', sans-serif;
      background: #F7F9FC;
      color: #0B1535;
      line-height: 1.5;
    }
    .container {
      max-width: 1280px;
      margin: 0 auto;
      padding: 0 24px;
    }
    /* ---------- colors ---------- */
    :root {
      --navy: #071A45;
      --dark-navy: #061333;
      --yellow: #FFC400;
      --gold: #FFB800;
      --white: #FFFFFF;
      --light-bg: #F7F9FC;
      --very-light-blue: #EEF3FF;
      --secondary-text: #4B556B;
      --border: #D9E0EC;
      --shadow-soft: 0 15px 40px rgba(7, 26, 69, 0.10);
      --shadow-card: 0 12px 28px rgba(7, 26, 69, 0.08);
    }
    /* ---------- header ---------- */
    .navbar-wrapper {
      padding-top: 16px;
      margin-bottom: 4px;
    }
    .navbar-custom {
      background: var(--navy);
      border-radius: 30px;
      padding: 6px 16px 6px 22px;
      box-shadow: var(--shadow-soft);
      border: 1px solid rgba(255,255,255,0.06);
      min-height: 72px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      width: 96%;
      margin: 0 auto;
    }
    .logo-area {
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .logo-icon {
      background: var(--yellow);
      width: 40px;
      height: 40px;
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: var(--navy);
      font-size: 20px;
      transform: rotate(-4deg);
      box-shadow: 0 4px 12px rgba(255, 196, 0, 0.3);
    }
    .logo-text .brand {
      font-size: 1.5rem;
      font-weight: 800;
      letter-spacing: -0.5px;
    }
    .logo-text .brand span:first-child { color: white; }
    .logo-text .brand span:last-child { color: var(--yellow); }
    .logo-text .sub {
      font-size: 0.6rem;
      color: rgba(255,255,255,0.5);
      letter-spacing: 0.4px;
      font-weight: 500;
      margin-top: -2px;
    }
    .nav-links {
      display: flex;
      align-items: center;
      gap: 6px;
      list-style: none;
      flex-wrap: wrap;
    }
    .nav-links a {
      color: white;
      text-decoration: none;
      font-weight: 600;
      font-size: 0.85rem;
      padding: 6px 14px;
      border-radius: 40px;
      transition: color 180ms ease, background-color 180ms ease;
    }
    .nav-links a.active {
      background: var(--yellow);
      color: var(--navy);
    }
    .btn-cta-nav {
      background: var(--yellow);
      color: var(--navy);
      font-weight: 700;
      padding: 8px 20px;
      border-radius: 60px;
      border: none;
      font-size: 0.85rem;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      transition: transform 160ms ease, background-color 160ms ease, box-shadow 160ms ease;
      cursor: pointer;
      box-shadow: 0 4px 12px rgba(255, 196, 0, 0.3);
    }
    .btn-cta-nav:hover {
      transform: translateY(-1px);
      background: #FFD633;
      box-shadow: 0 6px 16px rgba(255, 196, 0, 0.35);
    }
    .hamburger {
      display: none;
      font-size: 1.6rem;
      color: white;
      background: transparent;
      border: none;
      cursor: pointer;
    }
    /* ---------- hero ---------- */
    .hero {
      padding: 16px 0 20px;
      background: white;
      border-radius: 32px 32px 0 0;
      margin-top: 4px;
      overflow: hidden;
    }
    .hero-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
      align-items: center;
    }
    .hero-left { padding-right: 16px; }
    .hero-headline {
      font-size: clamp(2.2rem, 5vw, 3.8rem);
      font-weight: 800;
      line-height: 1.1;
      letter-spacing: -1px;
      margin-bottom: 8px;
    }
    .hero-headline .highlight { color: var(--yellow); }
    .hero-tagline {
      font-weight: 700;
      color: var(--navy);
      font-size: 0.95rem;
      margin-bottom: 12px;
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 4px 10px;
    }
    .hero-tagline .dot {
      color: var(--yellow);
      font-size: 1.2rem;
    }
    .hero-desc {
      font-size: 0.95rem;
      color: var(--secondary-text);
      max-width: 400px;
      margin-bottom: 20px;
      font-weight: 500;
    }
    .hero-buttons {
      display: flex;
      flex-wrap: wrap;
      gap: 12px;
      margin-bottom: 24px;
    }
    .btn-primary {
      background: var(--yellow);
      border: none;
      padding: 12px 28px;
      border-radius: 60px;
      font-weight: 700;
      color: var(--navy);
      font-size: 0.9rem;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      box-shadow: 0 6px 18px rgba(255, 196, 0, 0.3);
      transition: transform 160ms ease, background-color 160ms ease, box-shadow 160ms ease;
      cursor: pointer;
    }
    .btn-primary:hover { transform: translateY(-1px); background: #FFD633; box-shadow: 0 8px 20px rgba(255, 196, 0, 0.35); }
    .btn-secondary {
      background: white;
      border: 1.5px solid var(--navy);
      padding: 12px 28px;
      border-radius: 60px;
      font-weight: 700;
      color: var(--navy);
      font-size: 0.9rem;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: background-color 160ms ease, color 160ms ease, border-color 160ms ease;
      cursor: pointer;
    }
    .btn-secondary:hover { background: var(--navy); color: white; }
    /* hero right - 3 real phones */
    .hero-right {
      position: relative;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 10px 0;
    }
    .phone-stack {
      position: relative;
      width: 100%;
      max-width: 520px;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 340px;
    }
    .phone-item {
      position: absolute;
      width: 44%;
      border-radius: 24px;
      box-shadow: 0 25px 50px rgba(7,26,69,0.22);
      background: #0B2357;
      overflow: hidden;
      border: 3px solid rgba(255,255,255,0.1);
    }
    .phone-item img {
      width: 100%;
      height: auto;
      display: block;
      border-radius: 20px;
    }
    .phone-item:nth-child(1) {
      left: 0;
      top: 8%;
      z-index: 1;
      transform: rotate(-14deg) translateY(-8px);
      width: 38%;
    }
    .phone-item:nth-child(2) {
      left: 28%;
      top: -8%;
      z-index: 3;
      width: 48%;
      transform: rotate(2deg);
      box-shadow: 0 30px 60px rgba(7,26,69,0.3);
      border-color: rgba(255,196,0,0.2);
    }
    .phone-item:nth-child(3) {
      right: 0;
      bottom: 2%;
      z-index: 2;
      transform: rotate(16deg) translateY(10px);
      width: 36%;
    }
    .phone-item .crack-effect {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: radial-gradient(circle at 35% 30%, rgba(255,196,0,0.06) 0%, transparent 60%);
      pointer-events: none;
      border-radius: 20px;
    }
    .phone-item .crack-effect::after {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: repeating-linear-gradient(45deg, transparent, transparent 40px, rgba(255,196,0,0.03) 40px, rgba(255,196,0,0.03) 41px);
      border-radius: 20px;
      pointer-events: none;
    }
    .yellow-swoosh-bg {
      position: absolute;
      width: 90%;
      height: 80%;
      top: 10%;
      left: 5%;
      background: var(--yellow);
      border-radius: 50% 30% 40% 60% / 60% 40% 50% 30%;
      opacity: 0.08;
      z-index: 0;
      filter: blur(14px);
    }
    .trust-cards {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
    }
    .trust-card {
      background: white;
      border-radius: 16px;
      padding: 8px 14px 8px 12px;
      box-shadow: var(--shadow-card);
      display: flex;
      align-items: center;
      gap: 10px;
      border: 1px solid rgba(217,224,236,0.2);
      flex: 1 0 auto;
      min-width: 100px;
    }
    .trust-card i {
      color: var(--navy);
      font-size: 1.2rem;
      background: var(--very-light-blue);
      padding: 8px;
      border-radius: 12px;
    }
    .trust-card .label { font-weight: 700; font-size: 0.75rem; color: var(--navy); }
    .trust-card .sub { font-size: 0.6rem; color: var(--secondary-text); }
    /* feature row */
    .feature-row {
      background: white;
      padding: 24px 0 12px;
      border-top: 1px solid var(--border);
      display: flex;
      flex-wrap: wrap;
      justify-content: space-around;
      gap: 8px;
      margin-top: 8px;
    }
    .feature-item {
      display: flex;
      align-items: center;
      gap: 10px;
      flex: 0 1 auto;
      padding: 4px 8px;
    }
    .feature-item .icon-circle {
      background: var(--yellow);
      width: 40px;
      height: 40px;
      border-radius: 60px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: var(--navy);
      font-size: 1.2rem;
      box-shadow: 0 4px 10px rgba(255,196,0,0.2);
    }
    .feature-item .info .title { font-weight: 700; color: var(--navy); font-size: 0.8rem; }
    .feature-item .info .desc { font-size: 0.65rem; color: var(--secondary-text); }
    .feature-divider {
      width: 1px;
      background: var(--border);
      height: 30px;
      align-self: center;
    }
    /* how it works - enhanced */
    .how-section {
      background: var(--light-bg);
      padding: 50px 0 50px;
      border-radius: 32px 32px 0 0;
      margin-top: 6px;
      position: relative;
    }
    .how-section::before {
      content: '';
      position: absolute;
      top: -30px;
      left: 50%;
      transform: translateX(-50%);
      width: 120px;
      height: 60px;
      background: var(--yellow);
      border-radius: 60% 60% 0 0 / 100% 100% 0 0;
      opacity: 0.08;
      filter: blur(8px);
    }
    .section-title {
      font-size: 2.2rem;
      font-weight: 800;
      text-align: center;
      color: var(--navy);
      margin-bottom: 6px;
    }
    .title-underline {
      width: 60px;
      height: 4px;
      background: var(--yellow);
      border-radius: 20px;
      margin: 0 auto 32px;
    }
    .steps-grid-enhanced {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 16px;
      align-items: stretch;
      position: relative;
    }
    .step-card-enhanced {
      background: white;
      border-radius: 24px;
      padding: 24px 16px 20px;
      box-shadow: var(--shadow-card);
      text-align: center;
      transition: transform 180ms ease, box-shadow 180ms ease, border-color 180ms ease;
      border: 2px solid transparent;
      position: relative;
      overflow: hidden;
    }
    .step-card-enhanced::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 4px;
      background: var(--yellow);
      transform: scaleX(0);
      transition: transform 180ms ease;
    }
    .step-card-enhanced:hover::before { transform: scaleX(1); }
    .step-card-enhanced:hover {
      transform: translateY(-2px);
      box-shadow: 0 14px 30px rgba(7,26,69,0.12);
      border-color: rgba(255,196,0,0.2);
    }
    .step-number-enhanced {
      font-size: 3rem;
      font-weight: 800;
      color: var(--yellow);
      opacity: 0.15;
      position: absolute;
      top: -8px;
      right: 12px;
      line-height: 1;
    }
    .step-icon-enhanced {
      background: var(--very-light-blue);
      width: 64px;
      height: 64px;
      border-radius: 60px;
      display: flex;
      margin: 0 auto 14px;
      align-items: center;
      justify-content: center;
      font-size: 1.8rem;
      color: var(--navy);
      transition: background-color 180ms ease, box-shadow 180ms ease;
    }
    .step-card-enhanced:hover .step-icon-enhanced {
      background: var(--yellow);
      box-shadow: 0 8px 20px rgba(255,196,0,0.25);
    }
    .step-card-enhanced h4 {
      font-weight: 700;
      font-size: 1.05rem;
      margin-bottom: 4px;
      color: var(--navy);
    }
    .step-card-enhanced p {
      color: var(--secondary-text);
      font-size: 0.85rem;
      font-weight: 500;
    }
    .step-arrow-enhanced {
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.6rem;
      color: var(--navy);
      opacity: 0.25;
      font-weight: 300;
    }
    /* cta card */
    .cta-card-section {
      padding: 20px 0 40px;
      background: var(--light-bg);
    }
    .cta-card {
      background: var(--yellow);
      border-radius: 32px;
      padding: 28px 36px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 20px;
      box-shadow: 0 20px 40px rgba(255, 196, 0, 0.2);
    }
    .cta-left {
      display: flex;
      align-items: center;
      gap: 18px;
    }
    .cta-left i {
      font-size: 2.8rem;
      color: var(--navy);
      background: rgba(7,26,69,0.08);
      padding: 14px;
      border-radius: 60px;
    }
    .cta-text h2 {
      font-weight: 800;
      color: var(--navy);
      font-size: 1.6rem;
    }
    .cta-text p { color: var(--navy); opacity: 0.8; font-weight: 500; font-size: 0.9rem; }
    .btn-cta-dark {
      background: var(--navy);
      color: white;
      border: none;
      padding: 12px 32px;
      border-radius: 60px;
      font-weight: 700;
      font-size: 0.95rem;
      display: inline-flex;
      align-items: center;
      gap: 10px;
      transition: transform 160ms ease, background-color 160ms ease, box-shadow 160ms ease;
      cursor: pointer;
      box-shadow: 0 6px 16px rgba(7,26,69,0.2);
    }
    .btn-cta-dark:hover { background: #0B2357; transform: translateY(-1px); box-shadow: 0 8px 20px rgba(7,26,69,0.26); }
    /* footer - professional */
    .footer {
      background: var(--navy);
      color: rgba(255,255,255,0.7);
      padding: 36px 0 16px;
      border-radius: 32px 32px 0 0;
      margin-top: 6px;
      border-top: 3px solid var(--yellow);
    }
    .footer-grid-prof {
      display: grid;
      grid-template-columns: 2fr 1fr 1fr 1fr;
      gap: 30px;
      margin-bottom: 28px;
    }
    .footer-brand-prof .brand {
      font-size: 1.6rem;
      font-weight: 800;
    }
    .footer-brand-prof .brand span:first-child { color: white; }
    .footer-brand-prof .brand span:last-child { color: var(--yellow); }
    .footer-brand-prof .sub {
      font-size: 0.6rem;
      color: rgba(255,255,255,0.4);
      letter-spacing: 0.4px;
      margin-top: 2px;
    }
    .footer-brand-prof p {
      margin-top: 10px;
      font-size: 0.85rem;
      max-width: 280px;
      line-height: 1.6;
      color: rgba(255,255,255,0.5);
    }
    .footer-social-prof {
      display: flex;
      gap: 10px;
      margin-top: 14px;
    }
    .footer-social-prof a {
      background: rgba(255,255,255,0.06);
      width: 38px;
      height: 38px;
      border-radius: 60px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: rgba(255,255,255,0.6);
      transition: background-color 180ms ease, color 180ms ease, transform 180ms ease;
      text-decoration: none;
      font-size: 1rem;
    }
    .footer-social-prof a:hover { background: var(--yellow); color: var(--navy); transform: translateY(-1px); }
    .footer h5 {
      color: white;
      font-weight: 700;
      font-size: 0.95rem;
      margin-bottom: 14px;
      letter-spacing: 0.3px;
    }
    .footer ul {
      list-style: none;
    }
    .footer ul li { margin-bottom: 8px; }
    .footer ul a {
      color: rgba(255,255,255,0.5);
      text-decoration: none;
      transition: color 180ms ease, transform 180ms ease;
      font-size: 0.85rem;
    }
    .footer ul a:hover { color: var(--yellow); transform: translateX(2px); }
    .footer-bottom-prof {
      border-top: 1px solid rgba(255,255,255,0.06);
      padding-top: 16px;
      display: flex;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 10px;
      font-size: 0.75rem;
      color: rgba(255,255,255,0.35);
    }
    /* responsive */
    @media (max-width: 1024px) {
      .hero-grid { grid-template-columns: 1fr; }
      .hero-left { padding-right: 0; }
      .hero-right { margin-top: 12px; }
      .phone-stack { max-width: 400px; min-height: 280px; }
      .steps-grid-enhanced { grid-template-columns: repeat(2,1fr); }
      .step-arrow-enhanced { display: none; }
      .footer-grid-prof { grid-template-columns: 1fr 1fr; }
    }
    @media (max-width: 768px) {
      .navbar-custom { padding: 8px 14px; min-height: 64px; width: 98%; }
      .nav-links {
        display: flex;
        flex-direction: column;
        width: 100%;
        gap: 4px;
        max-height: 0;
        opacity: 0;
        overflow: hidden;
        visibility: hidden;
        transition: max-height 220ms ease, opacity 220ms ease, visibility 220ms ease;
      }
      .nav-links.open {
        max-height: 340px;
        padding: 12px 0 8px;
        opacity: 1;
        visibility: visible;
      }
      .hamburger { display: block; }
      .nav-links a { width: 100%; justify-content: center; padding: 6px 12px; font-size: 0.8rem; }
      .btn-cta-nav { width: 100%; justify-content: center; }
      .hero-headline { font-size: 2rem; }
      .feature-row { flex-direction: column; align-items: stretch; }
      .feature-divider { display: none; }
      .steps-grid-enhanced { grid-template-columns: 1fr; max-width: 340px; margin: 0 auto; }
      .cta-card { flex-direction: column; text-align: center; padding: 24px 18px; }
      .cta-left { flex-direction: column; }
      .trust-cards { flex-direction: column; }
      .footer-grid-prof { grid-template-columns: 1fr; gap: 24px; text-align: center; }
      .footer-brand-prof p { margin-left: auto; margin-right: auto; }
      .footer-social-prof { justify-content: center; }
      .phone-stack { min-height: 220px; max-width: 300px; }
      .phone-item { width: 40% !important; }
      .phone-item:nth-child(2) { width: 45% !important; }
      .footer-bottom-prof { flex-direction: column; align-items: center; text-align: center; }
    }
    @media (max-width: 480px) {
      .hero-headline { font-size: 1.7rem; }
      .hero-buttons { flex-direction: column; }
      .btn-primary, .btn-secondary { justify-content: center; font-size: 0.8rem; padding: 10px 20px; }
      .cta-text h2 { font-size: 1.3rem; }
      .phone-stack { min-height: 180px; max-width: 240px; }
    }
    a { cursor: pointer; }
    html { scroll-behavior: smooth; }
    img { max-width: 100%; height: auto; }
    @media (prefers-reduced-motion: reduce) {
      *,
      *::before,
      *::after {
        animation-duration: 0.01ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: 0.01ms !important;
        scroll-behavior: auto !important;
      }
    }
  </style>
</head>
<body>

<div class="navbar-wrapper">
  <nav class="navbar-custom">
    <div class="logo-area">
      <div class="logo-icon"><i class="fas fa-mobile-alt"></i></div>
      <div class="logo-text">
        <div class="brand"><span>Mobile</span><span>Fix</span></div>
        <div class="sub">Repair Management</div>
      </div>
    </div>
    <button class="hamburger" id="hamburgerBtn" aria-label="menu"><i class="fas fa-bars"></i></button>
    <ul class="nav-links" id="navLinks">
      <li><a href="index.php" class="active">Home</a></li>
      <li><a href="#features">Features</a></li>
      <li><a href="#how-it-works">How It Works</a></li>
      <li><a href="track-repair.php">Track Repair</a></li>
      <li><a href="<?php echo $loginHref; ?>"><?php echo $loginLabel; ?></a></li>
      <li><a href="<?php echo $startHref; ?>" class="btn-cta-nav"><i class="fas fa-user"></i> <?php echo $startLabel; ?></a></li>
    </ul>
  </nav>
</div>

<main>
  <!-- hero -->
  <section class="hero">
    <div class="container hero-grid">
      <div class="hero-left">
        <h1 class="hero-headline">
          Online <span class="highlight">Mobile</span><br>
          Repair<br>
          Management
        </h1>
        <div class="hero-tagline">
          <span>Request</span><span class="dot">•</span>
          <span>Track</span><span class="dot">•</span>
          <span>Repair</span><span class="dot">•</span>
          <span>Collect</span>
        </div>
        <p class="hero-desc">Request a repair, track its progress, get it fixed, and collect your phone — all in one place.</p>
        <div class="hero-buttons">
          <a href="<?php echo $submitUrl; ?>" class="btn-primary" style="text-decoration:none;"><i class="fas fa-wrench"></i> Submit Request</a>
          <a href="track-repair.php" class="btn-secondary" style="text-decoration:none;"><i class="fas fa-eye"></i> Track Status</a>
        </div>
        <div class="trust-cards">
          <div class="trust-card"><i class="fas fa-clock"></i><div><div class="label">Simple Requests</div><div class="sub">Submit in minutes</div></div></div>
          <div class="trust-card"><i class="fas fa-route"></i><div><div class="label">Repair Tracking</div><div class="sub">See every step</div></div></div>
          <div class="trust-card"><i class="fas fa-file-invoice"></i><div><div class="label">Clear Billing</div><div class="sub">Honest invoices</div></div></div>
        </div>
      </div>
      <div class="hero-right">
        <div class="phone-stack">
          <div class="yellow-swoosh-bg"></div>
          <!-- 3 real phone images (unsplash) -->
          <div class="phone-item">
            <img src="https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=300&h=500&fit=crop&crop=center&auto=format" alt="iPhone with cracked screen" loading="lazy">
            <div class="crack-effect"></div>
          </div>
          <div class="phone-item">
            <img src="https://images.unsplash.com/photo-1565849904461-3d2f5a1b7c6f?w=300&h=500&fit=crop&crop=center&auto=format" alt="Samsung phone with damaged screen" loading="lazy">
            <div class="crack-effect"></div>
          </div>
          <div class="phone-item">
            <img src="https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?w=300&h=500&fit=crop&crop=center&auto=format" alt="Phone with cracked glass" loading="lazy">
            <div class="crack-effect"></div>
          </div>
        </div>
      </div>
    </div>
    <!-- feature row -->
    <div class="container feature-row" id="features">
      <div class="feature-item"><div class="icon-circle"><i class="fas fa-mobile-alt"></i></div><div class="info"><div class="title">Quick Request</div><div class="desc">Submit in seconds</div></div></div>
      <div class="feature-divider"></div>
      <div class="feature-item"><div class="icon-circle"><i class="fas fa-route"></i></div><div class="info"><div class="title">Repair Tracking</div><div class="desc">Step-by-step status</div></div></div>
      <div class="feature-divider"></div>
      <div class="feature-item"><div class="icon-circle"><i class="fas fa-tools"></i></div><div class="info"><div class="title">Assigned Technicians</div><div class="desc">Skilled and dedicated</div></div></div>
      <div class="feature-divider"></div>
      <div class="feature-item"><div class="icon-circle"><i class="fas fa-file-invoice"></i></div><div class="info"><div class="title">Transparent Billing</div><div class="desc">Clear invoices</div></div></div>
    </div>
  </section>

  <!-- how it works - enhanced -->
  <section class="how-section" id="how-it-works">
    <div class="container">
      <h2 class="section-title">How It Works</h2>
      <div class="title-underline"></div>
      <div class="steps-grid-enhanced">
        <div class="step-card-enhanced">
          <div class="step-number-enhanced">01</div>
          <div class="step-icon-enhanced"><i class="fas fa-user-plus"></i></div>
          <h4>Create Account</h4>
          <p>Sign up in seconds</p>
        </div>
        <div class="step-arrow-enhanced"><i class="fas fa-arrow-right"></i></div>
        <div class="step-card-enhanced">
          <div class="step-number-enhanced">02</div>
          <div class="step-icon-enhanced"><i class="fas fa-mobile-alt"></i></div>
          <h4>Submit Request</h4>
          <p>Tell us the issue</p>
        </div>
        <div class="step-arrow-enhanced"><i class="fas fa-arrow-right"></i></div>
        <div class="step-card-enhanced">
          <div class="step-number-enhanced">03</div>
          <div class="step-icon-enhanced"><i class="fas fa-tools"></i></div>
          <h4>Repair & Updates</h4>
          <p>Technicians update progress</p>
        </div>
        <div class="step-arrow-enhanced"><i class="fas fa-arrow-right"></i></div>
        <div class="step-card-enhanced">
          <div class="step-number-enhanced">04</div>
          <div class="step-icon-enhanced"><i class="fas fa-check-circle"></i></div>
          <h4>Collect & Pay</h4>
          <p>Pick up your device</p>
        </div>
      </div>
    </div>
  </section>

  <!-- cta card -->
  <section class="cta-card-section">
    <div class="container">
      <div class="cta-card">
        <div class="cta-left">
          <i class="fas fa-mobile-alt"></i>
          <div class="cta-text">
            <h2>Ready to fix your phone?</h2>
            <p>Submit a repair request in a few minutes.</p>
          </div>
        </div>
        <a href="<?php echo $startHref; ?>" class="btn-cta-dark" style="text-decoration:none;"><?php echo $startLabel; ?> <i class="fas fa-arrow-right"></i></a>
      </div>
    </div>
  </section>
</main>

<!-- footer - professional -->
<footer class="footer">
  <div class="container">
    <div class="footer-grid-prof">
      <div class="footer-brand-prof">
        <div class="brand"><span>Mobile</span><span>Fix</span></div>
        <div class="sub">Repair Management System</div>
        <p>Streamline your mobile repair business with our all-in-one platform. Request, track, repair, collect — everything in one place.</p>
        <div class="footer-social-prof">
          <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
          <a href="#" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
          <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
          <a href="#" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
        </div>
      </div>
      <div>
        <h5>Company</h5>
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="#features">Features</a></li>
          <li><a href="#how-it-works">How It Works</a></li>
          <li><a href="<?php echo $submitUrl; ?>">Submit Request</a></li>
        </ul>
      </div>
      <div>
        <h5>Support</h5>
        <ul>
          <li><a href="track-repair.php">Repair Tracking</a></li>
          <li><a href="<?php echo $submitUrl; ?>">Submit Request</a></li>
          <li><a href="<?php echo $loginHref; ?>"><?php echo $loginLabel; ?></a></li>
        </ul>
      </div>
      <div>
        <h5>Account</h5>
        <ul>
          <li><a href="register.php">Create Account</a></li>
          <li><a href="login.php">Login</a></li>
          <li><a href="<?php echo $dashUrl; ?>">Dashboard</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom-prof">
      <span>&copy; <?php echo date('Y'); ?> MobileFix. All rights reserved.</span>
      <span>Built with <i class="fas fa-heart" style="color: #FFC400;"></i> for better repair management</span>
    </div>
  </div>
</footer>

<script>
  (function() {
    const hamburger = document.getElementById('hamburgerBtn');
    const navLinks = document.getElementById('navLinks');
    hamburger.addEventListener('click', function() {
      navLinks.classList.toggle('open');
      const icon = this.querySelector('i');
      icon.classList.toggle('fa-bars');
      icon.classList.toggle('fa-times');
    });
    document.querySelectorAll('.nav-links a, .nav-links button').forEach(function(link) {
      link.addEventListener('click', function() {
        if (window.innerWidth < 768) {
          navLinks.classList.remove('open');
          const icon = hamburger.querySelector('i');
          icon.classList.add('fa-bars');
          icon.classList.remove('fa-times');
        }
      });
    });
  })();
</script>

</body>
</html>