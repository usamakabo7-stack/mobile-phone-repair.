<?php
// ============================================================
// MobileFix - One-time installer
// Reads database/schema.sql and creates the database & tables.
// Safe to re-run: tables are created with IF NOT EXISTS logic
// and the admin account is only seeded when missing.
// ============================================================

$config = require __DIR__ . '/config/config.php';
$db = $config['database'];

$messages = [];

try {
    // Connect without a database selected first
    $dsn = "mysql:host={$db['host']};charset={$db['charset']}";
    $pdo = new PDO($dsn, $db['username'], $db['password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$db['dbname']}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE `{$db['dbname']}`");
    $messages[] = 'Database <strong>' . $db['dbname'] . '</strong> is ready.';

    // Load schema.sql and split into statements
    $schemaFile = __DIR__ . '/database/schema.sql';
    $sql = file_get_contents($schemaFile);
    $sql = preg_replace('/^\s*--.*$/m', '', $sql);   // strip comment lines
    $statements = array_filter(array_map('trim', explode(';', $sql)));

    foreach ($statements as $statement) {
        if (trim($statement) === '') {
            continue;
        }
        $pdo->exec($statement);
    }

    $messages[] = 'All tables are in place (users, inventory, repair_requests, repair_parts, invoices, invoice_items, repair_status_history).';
    $messages[] = 'Default admin account is ready (<strong>admin@mobilefix.com</strong> / <strong>admin123</strong>).';

    $pdo = null;
    $ok = true;
} catch (PDOException $e) {
    $ok = false;
    $messages[] = 'Installation error: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MobileFix · Installer</title>
<style>
  body { font-family: 'Segoe UI', Arial, sans-serif; background:#F7F9FC; margin:0; color:#0B1535; }
  .card { max-width:600px; margin:80px auto; background:#fff; border-radius:20px; padding:36px;
          box-shadow:0 15px 40px rgba(7,26,69,0.10); border-top:6px solid #FFC400; }
  .brand { font-weight:800; font-size:1.4rem; letter-spacing:-0.5px; }
  .brand span:last-child { color:#FFC400; }
  ul { line-height:1.9; padding-left:20px; }
  .ok { color:#16A34A; font-weight:700; }
  .err { color:#DC2626; font-weight:700; }
  .btn { display:inline-block; margin-top:14px; background:#071A45; color:#fff; padding:10px 22px;
         border-radius:60px; text-decoration:none; font-weight:700; }
</style>
</head>
<body>
<div class="card">
  <div class="brand"><span>Mobile</span><span>Fix</span></div>
  <h2 style="margin:10px 0 4px">Installer</h2>
  <?php if ($ok): ?><p class="ok">Installation completed successfully.</p><?php else: ?><p class="err">Installation could not be completed.</p><?php endif; ?>
  <ul>
    <?php foreach ($messages as $m): ?>
      <li><?php echo $m; ?></li>
    <?php endforeach; ?>
  </ul>
  <a class="btn" href="index.php">Open MobileFix</a>
  <?php if ($ok): ?>
    <a class="btn" href="login.php" style="background:#FFC400;color:#071A45;">Go to Login</a>
  <?php endif; ?>
</div>
</body>
</html>
