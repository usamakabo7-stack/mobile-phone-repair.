(function () {
  'use strict';

  var body = document.body;

  /* ---------- Sidebar (mobile) ---------- */
  var sidebar = document.getElementById('sidebar');
  var hamburger = document.getElementById('hamburgerBtn');
  var overlay = document.getElementById('sidebarOverlay');

  function openSidebar() {
    if (!sidebar) return;
    body.classList.add('sidebar-open');
  }
  function closeSidebar() {
    body.classList.remove('sidebar-open');
  }

  if (hamburger) {
    hamburger.addEventListener('click', function () {
      if (body.classList.contains('sidebar-open')) { closeSidebar(); } else { openSidebar(); }
    });
  }
  if (overlay) {
    overlay.addEventListener('click', closeSidebar);
  }

  /* Close the mobile sidebar after clicking a nav link */
  if (sidebar) {
    sidebar.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        if (window.innerWidth <= 768) closeSidebar();
      });
    });
  }

  /* Close the mobile sidebar with the Escape key */
  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') closeSidebar();
  });

  /* ---------- Auto-dismiss alerts after 6 seconds ---------- */
  document.querySelectorAll('.alert').forEach(function (alertEl) {
    setTimeout(function () {
      if (alertEl.parentNode) {
        alertEl.style.transition = 'opacity 0.4s';
        alertEl.style.opacity = '0';
        setTimeout(function () { if (alertEl.parentNode) alertEl.parentNode.removeChild(alertEl); }, 420);
      }
    }, 6000);
  });

  /* ---------- Manual alert close buttons ---------- */
  document.querySelectorAll('.alert-close').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var alertEl = btn.closest('.alert');
      if (alertEl && alertEl.parentNode) alertEl.parentNode.removeChild(alertEl);
    });
  });

  /* ---------- Confirm dialogs (elements with data-confirm) ---------- */
  document.querySelectorAll('[data-confirm]').forEach(function (el) {
    el.addEventListener('click', function (event) {
      var message = el.getAttribute('data-confirm') || 'Are you sure?';
      if (!window.confirm(message)) {
        event.preventDefault();
        return false;
      }
      return true;
    });
  });

  /* ---------- Client-side table filtering ---------- */
  document.querySelectorAll('.table-filter').forEach(function (input) {
    input.addEventListener('input', function () {
      var q = this.value.toLowerCase().trim();
      var table = document.querySelector(this.getAttribute('data-target'));
      if (!table) return;
      var rows = table.querySelectorAll('tbody tr');
      rows.forEach(function (row) {
        if (q === '') { row.style.display = ''; return; }
        row.style.display = row.textContent.toLowerCase().indexOf(q) >= 0 ? '' : 'none';
      });
    });
  });

  /* ---------- Status dropdown helper (enable/disable submit) ---------- */
  var statusForm = document.getElementById('statusForm');
  if (statusForm) {
    var sel = statusForm.querySelector('select');
    var btn = statusForm.querySelector('button[type="submit"]');
    if (sel && btn) {
      var update = function () {
        btn.disabled = !sel.value;
      };
      sel.addEventListener('change', update);
      update();
    }
  }

  /* ---------- Toast notifications ---------- */
  function toast(type, message, title) {
    var icons = {
      success: 'fa-check-circle',
      error: 'fa-exclamation-circle',
      warning: 'fa-exclamation-triangle',
      info: 'fa-info-circle'
    };
    var kind = icons[type] ? type : 'info';
    var container = document.getElementById('toastContainer');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toastContainer';
      container.className = 'toast-container';
      document.body.appendChild(container);
    }
    var t = document.createElement('div');
    t.className = 'toast toast-' + kind;
    var titleHtml = title ? '<div class="toast-title"></div>' : '';
    t.innerHTML = '<i class="fas ' + icons[kind] + '"></i>'
      + '<div class="toast-body">' + titleHtml + '<div class="toast-msg"></div></div>'
      + '<button class="toast-close" type="button" aria-label="Dismiss">&times;</button>';
    if (title) t.querySelector('.toast-title').textContent = title;
    t.querySelector('.toast-msg').textContent = message;
    t.querySelector('.toast-close').addEventListener('click', function () {
      if (t.parentNode) t.parentNode.removeChild(t);
    });
    container.appendChild(t);
    setTimeout(function () {
      t.classList.add('toast-out');
      setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, 380);
    }, 4600);
  }
  window.mfxToast = toast;

  /* ---------- Loading states on POST forms ---------- */
  document.querySelectorAll('form[method="post"]').forEach(function (form) {
    form.addEventListener('submit', function () {
      var submitBtn = form.querySelector('button[type="submit"]');
      if (!submitBtn || submitBtn.disabled || submitBtn.classList.contains('btn-loading')) return;
      submitBtn.classList.add('btn-loading');
      submitBtn.disabled = true;
      var loadingText = submitBtn.getAttribute('data-loading') || 'Saving...';
      submitBtn.innerHTML = '<span class="spinner"></span><span>' + loadingText + '</span>';
    });
  });

  /* ---------- Lightweight client-side validation (UX only) ---------- */
  document.querySelectorAll('form.js-validate').forEach(function (form) {
    form.addEventListener('submit', function (event) {
      var firstInvalid = null;
      form.querySelectorAll('[required]').forEach(function (input) {
        var val = input.value.trim();
        var ok = val !== '';
        if (ok && input.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val)) ok = false;
        input.classList.toggle('is-invalid', !ok);
        if (!ok && !firstInvalid) firstInvalid = input;
      });
      if (firstInvalid) {
        event.preventDefault();
        firstInvalid.focus();
        toast('error', 'Please fill in the highlighted fields and try again.', 'Almost there');
      }
    });
    form.querySelectorAll('[required]').forEach(function (input) {
      input.addEventListener('input', function () {
        if (input.value.trim() !== '') {
          input.classList.remove('is-invalid');
          input.classList.add('is-valid');
        }
      });
      input.addEventListener('blur', function () {
        if (input.value.trim() !== '') {
          input.classList.add('is-valid');
        }
      });
    });
  });

  /* ---------- Password visibility toggle ---------- */
  document.querySelectorAll('.password-toggle').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var group = btn.closest('.input-group');
      if (!group) return;
      var input = group.querySelector('input');
      var show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      var icon = btn.querySelector('i');
      if (icon) icon.className = show ? 'fas fa-eye-slash' : 'fas fa-eye';
      btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
    });
  });
})();
