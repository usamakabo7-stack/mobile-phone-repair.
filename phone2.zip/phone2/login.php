<?php
require_once __DIR__ . '/includes/auth.php';

// Already signed in? Send to the right dashboard.
if (is_logged_in()) {
    redirect(dashboard_for_role(current_role()));
}

$errors = [];
$email  = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email    = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    if ($email === '' || $password === '') {
        $errors[] = 'Email and password are required.';
    } else {
        $result = attempt_login(db(), $email, $password);
        if ($result === null) {
            $errors[] = 'Invalid email or password. Please check your credentials and try again.';
        } elseif ($result === 'inactive') {
            $errors[] = 'Your account has been deactivated. Please contact the administrator.';
        } else {
            redirect(dashboard_for_role($result['role']));
        }
    }
}

$page_title = 'Login';
require_once __DIR__ . '/includes/public-header.php';
?>
<div class="auth-card">
  <div class="auth-brand">
    <div class="logo-icon"><i class="fas fa-mobile-alt"></i></div>
    <div>
      <div class="brand"><span>Mobile</span><span>Fix</span></div>
      <div class="sub">Repair Management System</div>
    </div>
  </div>

  <h1 class="auth-title">Welcome back</h1>
  <p class="auth-sub">Log in to manage your repairs.</p>

  <?php foreach ($errors as $error): ?>
    <div class="alert alert-error"><span><?php echo e($error); ?></span></div>
  <?php endforeach; ?>
  <?php render_flashes(); ?>

  <form method="post" action="login.php" novalidate class="js-validate">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <label for="email">Email Address <span class="req">*</span></label>
      <input type="email" class="form-control" id="email" name="email" value="<?php echo e($email); ?>" placeholder="you@example.com" required autofocus autocomplete="email">
    </div>
    <div class="form-group">
      <label for="password">Password <span class="req">*</span></label>
      <div class="input-group">
        <input type="password" class="form-control" id="password" name="password" placeholder="Your password" required autocomplete="current-password">
        <button type="button" class="input-icon password-toggle" aria-label="Show password" title="Show password"><i class="fas fa-eye"></i></button>
      </div>
    </div>
    <button type="submit" class="btn btn-primary btn-block" data-loading="Signing in..."><i class="fas fa-sign-in-alt"></i> Sign In</button>
  </form>

  <div class="auth-foot">
    Don't have an account? <a href="register.php">Create one</a><br>
    <span class="small muted">Track a repair without an account: <a href="track-repair.php">Track Repair</a></span>
  </div>
</div>
<?php require_once __DIR__ . '/includes/public-footer.php'; ?>
