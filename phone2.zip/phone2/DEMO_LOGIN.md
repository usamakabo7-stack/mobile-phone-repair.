# MobileFix — Demo Login Details

**Design and Implementation of an Online Mobile Repair Management System**

These are the demonstration accounts for presenting MobileFix.
Create them by running:

```bash
php database/seed_demo_users.php
```

---

## ADMIN

| | |
| --- | --- |
| **Role** | Admin |
| **Name** | MobileFix Administrator |
| **Email** | `admin@mobilefix.test` |
| **Password** | `Admin@12345` |

## TECHNICIAN

| | |
| --- | --- |
| **Role** | Technician |
| **Name** | MobileFix Technician |
| **Email** | `technician@mobilefix.test` |
| **Password** | `Tech@12345` |

## CUSTOMER

| | |
| --- | --- |
| **Role** | Customer |
| **Name** | Demo Customer |
| **Email** | `customer@mobilefix.test` |
| **Password** | `Customer@12345` |

---

## Role Overview

- **Admin** → manages the entire repair system (repairs, technicians, inventory, invoices, reports).
- **Technician** → manages assigned repair jobs (diagnosis, parts, status updates).
- **Customer** → submits and tracks repairs, views invoices.

---

### Suggested presentation flow

1. Open MobileFix → the landing page loads immediately.
2. Log in as **Customer** → submit a repair request.
3. Log in as **Admin** → assign the repair to the technician.
4. Log in as **Technician** → diagnose and update the repair.
5. Track the repair (customer / public tracking page).
6. View the invoice, mark it paid, and collect the device.
