<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['technician']);

$pdo = db();
$uid = current_user_id();

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id");
$stmt->execute([':id' => $uid]);
$profile = $stmt->fetch();

$errors = [];
$input = [
    'full_name' => $profile['full_name'],
    'phone'     => $profile['phone'],
    'email'     => $profile['email'],
    'specialization' => $profile['specialization'],
];

if (isset($_POST['action']) && $_POST['action'] === 'profile') {
    verify_csrf();
    $input['full_name'] = isset($_POST['full_name']) ? trim($_POST['full_name']) : '';
    $input['phone']     = isset($_POST['phone']) ? trim($_POST['phone']) : '';
    $input['email']     = isset($_POST['email']) ? strtolower(trim($_POST['email'])) : '';
    $input['specialization'] = isset($_POST['specialization']) ? trim($_POST['specialization']) : '';

    if ($input['full_name'] === '') {
        $errors[] = 'Full name is required.';
    }
    if ($input['phone'] === '') {
        $errors[] = 'Phone number is required.';
    }
    if (!filter_var($input['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }

    if (!$errors) {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = :email AND id != :id LIMIT 1");
        $stmt->execute([':email' => $input['email'], ':id' => $uid]);
        if ($stmt->fetch()) {
            $errors[] = 'That email is already used by another account.';
        }
    }

    if (!$errors) {
        $stmt = $pdo->prepare(
            "UPDATE users SET full_name = :name, phone = :phone, email = :email, specialization = :spec WHERE id = :id"
        );
        $stmt->execute([
            ':name'  => $input['full_name'],
            ':phone' => $input['phone'],
            ':email' => $input['email'],
            ':spec'  => $input['specialization'],
            ':id'    => $uid,
        ]);
        $_SESSION['user']['name']  = $input['full_name'];
        $_SESSION['user']['phone'] = $input['phone'];
        $_SESSION['user']['email'] = $input['email'];
        $_SESSION['user']['specialization'] = $input['specialization'];
        flash('success', 'Your profile has been updated.');
        redirect('profile.php');
    }
}

if (isset($_POST['action']) && $_POST['action'] === 'password') {
    verify_csrf();
    $current = isset($_POST['current_password']) ? $_POST['current_password'] : '';
    $new     = isset($_POST['new_password']) ? $_POST['new_password'] : '';
    $confirm = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';

    if (!password_verify($current, $profile['password'])) {
        $errors[] = 'Your current password is incorrect.';
    }
    if (strlen($new) < 6) {
        $errors[] = 'New password must be at least 6 characters.';
    }
    if ($new !== $confirm) {
        $errors[] = 'New passwords do not match.';
    }

    if (!$errors) {
        $stmt = $pdo->prepare("UPDATE users SET password = :pass WHERE id = :id");
        $stmt->execute([':pass' => password_hash($new, PASSWORD_DEFAULT), ':id' => $uid]);
        flash('success', 'Your password has been changed.');
        redirect('profile.php');
    }
}

$page_title = 'My Profile';
$active = 'Profile';
require_once __DIR__ . '/../includes/dash-header.php';
?>

<div class="page-head">
  <div>
    <h1>My Profile</h1>
    <p>Manage your account details and password.</p>
  </div>
</div>

<div class="grid-2">
  <div class="card">
    <div class="card-header"><div class="card-title">Profile Details</div></div>
    <div class="card-body">
      <?php foreach ($errors as $error): ?>
        <div class="alert alert-error"><span><?php echo e($error); ?></span></div>
      <?php endforeach; ?>

      <form method="post" action="profile.php" novalidate>
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="profile">
        <div class="form-group">
          <label for="full_name">Full Name</label>
          <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo e($input['full_name']); ?>" required>
        </div>
        <div class="form-group">
          <label for="phone">Phone Number</label>
          <input type="tel" class="form-control" id="phone" name="phone" value="<?php echo e($input['phone']); ?>" required>
        </div>
        <div class="form-group">
          <label for="email">Email Address</label>
          <input type="email" class="form-control" id="email" name="email" value="<?php echo e($input['email']); ?>" required>
        </div>
        <div class="form-group">
          <label for="specialization">Specialization</label>
          <input type="text" class="form-control" id="specialization" name="specialization" value="<?php echo e($input['specialization']); ?>" placeholder="e.g. Screen & Battery">
        </div>
        <button type="submit" class="btn btn-primary">Save Changes</button>
      </form>
    </div>
  </div>

  <div class="card">
    <div class="card-header"><div class="card-title">Change Password</div></div>
    <div class="card-body">
      <form method="post" action="profile.php" novalidate>
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="password">
        <div class="form-group">
          <label for="current_password">Current Password</label>
          <input type="password" class="form-control" id="current_password" name="current_password" required>
        </div>
        <div class="form-group">
          <label for="new_password">New Password</label>
          <input type="password" class="form-control" id="new_password" name="new_password" minlength="6" required>
        </div>
        <div class="form-group">
          <label for="confirm_password">Confirm New Password</label>
          <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
        </div>
        <button type="submit" class="btn btn-navy">Update Password</button>
      </form>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
