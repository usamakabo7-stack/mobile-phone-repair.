<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['technician']);

$pdo = db();
$uid = current_user_id();

// Job counts for this technician
$stmt = $pdo->prepare(
    "SELECT status, COUNT(*) AS c FROM repair_requests
     WHERE technician_id = :uid AND status != 'Cancelled' GROUP BY status"
);
$stmt->execute([':uid' => $uid]);
$counts = [];
foreach ($stmt->fetchAll() as $row) {
    $counts[$row['status']] = (int)$row['c'];
}

// Active jobs (need attention)
$stmt = $pdo->prepare(
    "SELECT r.*, u.full_name AS customer_name, u.phone AS customer_phone
     FROM repair_requests r
     JOIN users u ON u.id = r.customer_id
     WHERE r.technician_id = :uid AND r.status IN ('Assigned','Diagnosing','Repairing')
     ORDER BY r.updated_at DESC LIMIT 6"
);
$stmt->execute([':uid' => $uid]);
$activeJobs = $stmt->fetchAll();

$firstName = preg_replace('/\s+.*/', '', $_SESSION['user']['name']);

$page_title = 'Dashboard';
$active = 'Dashboard';
require_once __DIR__ . '/../includes/dash-header.php';
?>

<div class="page-head">
  <div>
    <h1>Welcome, <?php echo e($firstName); ?></h1>
    <p>Here are your assigned repair jobs.</p>
  </div>
</div>

<div class="stat-grid">
  <div class="stat-card blue">
    <div class="stat-icon"><i class="fas fa-user-tag"></i></div>
    <div>
      <div class="stat-value"><?php echo isset($counts['Assigned']) ? $counts['Assigned'] : 0; ?></div>
      <div class="stat-label">Assigned</div>
    </div>
  </div>
  <div class="stat-card purple">
    <div class="stat-icon"><i class="fas fa-stethoscope"></i></div>
    <div>
      <div class="stat-value"><?php echo isset($counts['Diagnosing']) ? $counts['Diagnosing'] : 0; ?></div>
      <div class="stat-label">Diagnosing</div>
    </div>
  </div>
  <div class="stat-card yellow">
    <div class="stat-icon"><i class="fas fa-tools"></i></div>
    <div>
      <div class="stat-value"><?php echo isset($counts['Repairing']) ? $counts['Repairing'] : 0; ?></div>
      <div class="stat-label">Repairing</div>
    </div>
  </div>
  <div class="stat-card green">
    <div class="stat-icon"><i class="fas fa-check-double"></i></div>
    <div>
      <div class="stat-value"><?php echo isset($counts['Completed']) ? $counts['Completed'] : 0; ?></div>
      <div class="stat-label">Completed</div>
    </div>
  </div>
</div>

<div class="page-head mt-2">
  <div>
    <h1 style="font-size:1.3rem;">Jobs Needing Attention</h1>
  </div>
  <a href="repairs.php" class="btn btn-ghost btn-sm">View all <i class="fas fa-arrow-right"></i></a>
</div>

<?php if ($activeJobs): ?>
  <div class="grid-2">
    <?php foreach ($activeJobs as $job): ?>
      <div class="repair-card">
        <div class="repair-card-top">
          <div class="repair-ref"><?php echo e($job['reference']); ?></div>
          <?php echo status_badge($job['status']); ?>
        </div>
        <div class="repair-device"><strong><?php echo e($job['brand'] . ' ' . $job['model']); ?></strong></div>
        <div class="repair-problem"><?php echo e($job['problem_type']); ?></div>
        <div class="repair-meta">
          <span><i class="fas fa-user"></i> <?php echo e($job['customer_name']); ?></span>
          <span><i class="fas fa-phone"></i> <?php echo e($job['customer_phone']); ?></span>
        </div>
        <div class="card-actions">
          <a href="repair-view.php?id=<?php echo (int)$job['id']; ?>" class="btn btn-navy btn-sm"><i class="fas fa-wrench"></i> View Repair</a>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
<?php else: ?>
  <div class="card">
    <?php echo empty_state('fas fa-check-circle', 'No active jobs', 'You have no pending repairs right now.'); ?>
  </div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
