<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['technician']);

$pdo = db();
$uid = current_user_id();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Ownership: a technician may ONLY access repairs assigned to them
$stmt = $pdo->prepare(
    "SELECT r.*, u.full_name AS customer_name, u.phone AS customer_phone
     FROM repair_requests r
     JOIN users u ON u.id = r.customer_id
     WHERE r.id = :id AND r.technician_id = :uid LIMIT 1"
);
$stmt->execute([':id' => $id, ':uid' => $uid]);
$repair = $stmt->fetch();

if (!$repair) {
    flash('error', 'Repair not found or this job is not assigned to you.');
    redirect('repairs.php');
}

$errors = [];

/* ---------- Save diagnosis / notes / service cost ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update') {
    verify_csrf();

    $diagnosis   = isset($_POST['diagnosis']) ? trim($_POST['diagnosis']) : '';
    $notes       = isset($_POST['repair_notes']) ? trim($_POST['repair_notes']) : '';
    $serviceCost = isset($_POST['service_cost']) ? trim($_POST['service_cost']) : '0';

    if (!is_numeric($serviceCost) || (float)$serviceCost < 0) {
        $errors[] = 'Service cost must be a valid amount (0 or more).';
    }

    if (!$errors) {
        $stmt = $pdo->prepare("UPDATE repair_requests SET diagnosis = :d, repair_notes = :n, service_cost = :c WHERE id = :id");
        $stmt->execute([
            ':d'  => $diagnosis,
            ':n'  => $notes,
            ':c'  => (float)$serviceCost,
            ':id' => $repair['id'],
        ]);
        sync_invoice($pdo, $repair);
        flash('success', 'Diagnosis, notes and service cost have been saved.');
        redirect('repair-view.php?id=' . $repair['id']);
    }
}

/* ---------- Update repair status ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'status') {
    verify_csrf();

    $nextStatuses = technician_next_statuses($repair['status']);
    $newStatus = isset($_POST['new_status']) ? trim($_POST['new_status']) : '';

    if (!in_array($newStatus, $nextStatuses, true)) {
        $errors[] = 'That status change is not allowed for this repair.';
    } elseif (!$errors) {
        $completedAt = ($newStatus === 'Completed') ? date('Y-m-d H:i:s') : null;
        $stmt = $pdo->prepare(
            "UPDATE repair_requests SET status = :status, completed_at = :completed WHERE id = :id"
        );
        $stmt->execute([
            ':status'    => $newStatus,
            ':completed' => $completedAt,
            ':id'        => $repair['id'],
        ]);
        log_status($pdo, $repair['id'], $newStatus, null, $uid);
        sync_invoice($pdo, $repair);

        flash('success', 'Repair status updated to <strong>' . $newStatus . '</strong>.');
        redirect('repair-view.php?id=' . $repair['id']);
    }
}

/* ---------- Add part (deduct stock server-side) ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_part') {
    verify_csrf();

    $inventoryId = isset($_POST['inventory_id']) ? (int)$_POST['inventory_id'] : 0;
    $quantity    = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 0;

    $stmt = $pdo->prepare("SELECT * FROM inventory WHERE id = :id AND status = 'active' LIMIT 1");
    $stmt->execute([':id' => $inventoryId]);
    $part = $stmt->fetch();

    if (!$part) {
        $errors[] = 'Selected part was not found or is inactive.';
    } elseif ($quantity < 1) {
        $errors[] = 'Quantity must be at least 1.';
    } elseif ($quantity > (int)$part['quantity']) {
        $errors[] = 'Not enough stock. Only ' . (int)$part['quantity'] . ' available.';
    }

    if (!$errors) {
        $pdo->beginTransaction();
        try {
            // Atomically deduct stock, verifying availability
            $deduct = $pdo->prepare(
                "UPDATE inventory SET quantity = quantity - ? WHERE id = ? AND quantity >= ?"
            );
            $deduct->execute([$quantity, $inventoryId, $quantity]);
            if ($deduct->rowCount() !== 1) {
                throw new RuntimeException('Could not deduct stock. Please check availability.');
            }

            $stmt = $pdo->prepare(
                "INSERT INTO repair_parts (repair_id, inventory_id, part_name, quantity, unit_price, subtotal)
                 VALUES (:rid, :inv, :name, :qty, :price, :subtotal)"
            );
            $stmt->execute([
                ':rid'      => $repair['id'],
                ':inv'      => $inventoryId,
                ':name'     => $part['part_name'],
                ':qty'      => $quantity,
                ':price'    => (float)$part['unit_price'],
                ':subtotal' => $quantity * (float)$part['unit_price'],
            ]);

            $pdo->commit();
            sync_invoice($pdo, $repair);
            flash('success', 'Part added to this repair and stock updated.');
            redirect('repair-view.php?id=' . $repair['id']);
        } catch (Exception $ex) {
            $pdo->rollBack();
            $errors[] = $ex->getMessage();
        }
    }
}

/* ---------- Remove part (restore stock) ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'remove_part') {
    verify_csrf();

    $partId = isset($_POST['part_id']) ? (int)$_POST['part_id'] : 0;
    $stmt = $pdo->prepare("SELECT * FROM repair_parts WHERE id = :id AND repair_id = :rid LIMIT 1");
    $stmt->execute([':id' => $partId, ':rid' => $repair['id']]);
    $rp = $stmt->fetch();

    if (!$rp) {
        $errors[] = 'Part record not found.';
    } else {
        $pdo->beginTransaction();
        try {
            if ($rp['inventory_id']) {
                $restore = $pdo->prepare("UPDATE inventory SET quantity = quantity + :qty WHERE id = :id");
                $restore->execute([':qty' => (int)$rp['quantity'], ':id' => (int)$rp['inventory_id']]);
            }
            $pdo->prepare("DELETE FROM repair_parts WHERE id = :id")->execute([':id' => $partId]);
            $pdo->commit();
            sync_invoice($pdo, $repair);
            flash('success', 'Part removed and stock restored.');
            redirect('repair-view.php?id=' . $repair['id']);
        } catch (Exception $ex) {
            $pdo->rollBack();
            $errors[] = 'Could not remove the part. Please try again.';
        }
    }
}

/* ---------- Load data for display ---------- */
$history = get_history($pdo, $repair['id']);
$parts   = get_repair_parts($pdo, $repair['id']);
$invoice = get_invoice_for_repair($pdo, $repair['id']);
$partsCost = parts_cost_for_repair($pdo, $repair['id']);

// Available parts for the add-part form
$stmt = $pdo->query("SELECT * FROM inventory WHERE status = 'active' AND quantity > 0 ORDER BY part_name");
$availableParts = $stmt->fetchAll();

$nextStatuses = technician_next_statuses($repair['status']);
$canWork = in_array($repair['status'], ['Assigned', 'Diagnosing', 'Repairing'], true);

$page_title = $repair['reference'];
$active = 'My Repairs';
require_once __DIR__ . '/../includes/dash-header.php';
?>

<div class="page-head">
  <div>
    <h1><?php echo e($repair['reference']); ?></h1>
    <p>Assigned to you · Updated <?php echo e(format_datetime($repair['updated_at'])); ?></p>
  </div>
  <?php echo status_badge($repair['status']); ?>
</div>

<?php foreach ($errors as $error): ?>
  <div class="alert alert-error"><span><?php echo e($error); ?></span></div>
<?php endforeach; ?>

<div class="grid-2">
  <div>
    <div class="card">
      <div class="card-header"><div class="card-title">Job Details</div></div>
      <div class="card-body">
        <div class="meta-list">
          <div class="meta-item">
            <div class="m-label">Customer</div>
            <div class="m-value"><?php echo e($repair['customer_name']); ?></div>
          </div>
          <div class="meta-item">
            <div class="m-label">Customer Phone</div>
            <div class="m-value"><?php echo e($repair['customer_phone']); ?></div>
          </div>
          <div class="meta-item">
            <div class="m-label">Device</div>
            <div class="m-value"><?php echo e($repair['brand'] . ' ' . $repair['model']); ?></div>
          </div>
          <div class="meta-item">
            <div class="m-label">Problem Type</div>
            <div class="m-value"><?php echo e($repair['problem_type']); ?></div>
          </div>
          <?php if ($repair['imei']): ?>
            <div class="meta-item">
              <div class="m-label">IMEI</div>
              <div class="m-value"><?php echo e($repair['imei']); ?></div>
            </div>
          <?php endif; ?>
        </div>
        <hr class="divider">
        <div class="m-label mb-1">Customer Description</div>
        <p class="muted"><?php echo nl2br(e($repair['description'])); ?></p>
      </div>
    </div>

    <?php if ($canWork): ?>
      <div class="card">
        <div class="card-header"><div class="card-title">Diagnosis, Notes &amp; Service Cost</div></div>
        <div class="card-body">
          <form method="post" action="repair-view.php?id=<?php echo (int)$repair['id']; ?>" novalidate>
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="update">
            <div class="form-group">
              <label for="diagnosis">Diagnosis</label>
              <textarea class="form-control" id="diagnosis" name="diagnosis" placeholder="e.g. Screen and display connector damaged."><?php echo e($repair['diagnosis']); ?></textarea>
            </div>
            <div class="form-group">
              <label for="repair_notes">Repair Notes</label>
              <textarea class="form-control" id="repair_notes" name="repair_notes" placeholder="e.g. Screen replaced and tested successfully."><?php echo e($repair['repair_notes']); ?></textarea>
            </div>
            <div class="form-group">
              <label for="service_cost">Service / Labour Cost</label>
              <input type="number" step="0.01" min="0" class="form-control" id="service_cost" name="service_cost"
                     value="<?php echo e(number_format((float)$repair['service_cost'], 2, '.', '')); ?>" placeholder="e.g. 10000">
            </div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Progress</button>
          </form>
        </div>
      </div>
    <?php endif; ?>
  </div>

  <div>
    <?php if ($canWork && $nextStatuses): ?>
      <div class="card">
        <div class="card-header"><div class="card-title">Update Status</div></div>
        <div class="card-body">
          <form method="post" action="repair-view.php?id=<?php echo (int)$repair['id']; ?>" id="statusForm">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="status">
            <div class="form-group">
              <label for="new_status">Move repair to</label>
              <select class="form-control" id="new_status" name="new_status" required>
                <option value="">-- Select next status --</option>
                <?php foreach ($nextStatuses as $ns): ?>
                  <option value="<?php echo e($ns); ?>"><?php echo e($ns); ?></option>
                <?php endforeach; ?>
              </select>
              <div class="form-hint">Current status: <?php echo e($repair['status']); ?></div>
            </div>
            <button type="submit" class="btn btn-navy"><i class="fas fa-arrow-circle-right"></i> Update Status</button>
          </form>
        </div>
      </div>
    <?php endif; ?>

    <?php if ($canWork): ?>
      <div class="card">
        <div class="card-header"><div class="card-title">Parts Used</div></div>
        <div class="card-body">
          <form method="post" action="repair-view.php?id=<?php echo (int)$repair['id']; ?>" class="form-row" novalidate>
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="add_part">
            <div class="form-group">
              <label for="inventory_id">Part</label>
              <select class="form-control" id="inventory_id" name="inventory_id" required>
                <option value="">-- Select part --</option>
                <?php foreach ($availableParts as $p): ?>
                  <option value="<?php echo (int)$p['id']; ?>">
                    <?php echo e($p['part_name']); ?> (<?php echo (int)$p['quantity']; ?> left · <?php echo format_money($p['unit_price']); ?>)
                  </option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label for="quantity">Quantity</label>
              <input type="number" min="1" max="999" class="form-control" id="quantity" name="quantity" value="1" required>
            </div>
            <div style="align-self:end;">
              <button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> Add Part</button>
            </div>
          </form>

          <?php if ($parts): ?>
            <table class="table mt-3">
              <thead>
                <tr><th>Part</th><th>Qty</th><th class="text-right">Amount</th><th></th></tr>
              </thead>
              <tbody>
                <?php foreach ($parts as $part): ?>
                  <tr>
                    <td><?php echo e($part['part_name']); ?></td>
                    <td><?php echo (int)$part['quantity']; ?></td>
                    <td class="text-right"><?php echo format_money($part['subtotal']); ?></td>
                    <td class="text-right">
                      <form method="post" action="repair-view.php?id=<?php echo (int)$repair['id']; ?>" class="inline-form" data-confirm="Remove this part and restore its stock?">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="action" value="remove_part">
                        <input type="hidden" name="part_id" value="<?php echo (int)$part['id']; ?>">
                        <button type="submit" class="btn btn-danger btn-xs"><i class="fas fa-trash"></i></button>
                      </form>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          <?php else: ?>
            <p class="muted small mt-2">No parts recorded yet.</p>
          <?php endif; ?>
        </div>
      </div>
    <?php endif; ?>

    <div class="card">
      <div class="card-header"><div class="card-title">Current Bill</div></div>
      <div class="card-body">
        <div class="meta-list">
          <div class="meta-item">
            <div class="m-label">Service / Labour</div>
            <div class="m-value"><?php echo format_money($repair['service_cost']); ?></div>
          </div>
          <div class="meta-item">
            <div class="m-label">Parts</div>
            <div class="m-value"><?php echo format_money($partsCost); ?></div>
          </div>
          <div class="meta-item">
            <div class="m-label">Total</div>
            <div class="m-value"><?php echo format_money((float)$repair['service_cost'] + $partsCost); ?></div>
          </div>
          <?php if ($invoice): ?>
            <div class="meta-item">
              <div class="m-label">Invoice</div>
              <div class="m-value"><?php echo e($invoice['invoice_no']); ?></div>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="card">
  <div class="card-header"><div class="card-title">Repair Progress</div></div>
  <div class="card-body">
    <?php echo repair_timeline($history, $repair['status']); ?>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
