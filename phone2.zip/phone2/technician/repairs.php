<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['technician']);

$pdo = db();
$uid = current_user_id();

$statusFilter = isset($_GET['status']) ? trim($_GET['status']) : '';
$allowed = ['Assigned', 'Diagnosing', 'Repairing', 'Completed', 'Collected', 'Cancelled'];

$sql = "SELECT r.*, u.full_name AS customer_name, u.phone AS customer_phone
        FROM repair_requests r
        JOIN users u ON u.id = r.customer_id
        WHERE r.technician_id = :uid";
$params = [':uid' => $uid];

if ($statusFilter !== '' && in_array($statusFilter, $allowed, true)) {
    $sql .= " AND r.status = :status";
    $params[':status'] = $statusFilter;
}
$sql .= " ORDER BY r.updated_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$jobs = $stmt->fetchAll();

$page_title = 'My Repairs';
$active = 'My Repairs';
require_once __DIR__ . '/../includes/dash-header.php';
?>

<div class="page-head">
  <div>
    <h1>My Repairs</h1>
    <p>Repair jobs assigned to you.</p>
  </div>
  <form method="get" action="repairs.php" class="filter-bar">
    <select name="status" class="form-control">
      <option value="">All Statuses</option>
      <?php foreach ($allowed as $s): ?>
        <option value="<?php echo e($s); ?>" <?php echo ($statusFilter === $s) ? 'selected' : ''; ?>><?php echo e($s); ?></option>
      <?php endforeach; ?>
    </select>
    <button type="submit" class="btn btn-outline btn-sm">Filter</button>
  </form>
</div>

<div class="card">
  <?php if ($jobs): ?>
    <div class="table-wrap">
      <table class="table">
        <thead>
          <tr>
            <th>Reference</th>
            <th>Device</th>
            <th>Problem</th>
            <th>Customer</th>
            <th>Status</th>
            <th>Updated</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($jobs as $job): ?>
            <tr>
              <td><strong><?php echo e($job['reference']); ?></strong></td>
              <td><?php echo e($job['brand'] . ' ' . $job['model']); ?></td>
              <td class="table-muted"><?php echo e($job['problem_type']); ?></td>
              <td><?php echo e($job['customer_name']); ?></td>
              <td><?php echo status_badge($job['status']); ?></td>
              <td class="table-muted"><?php echo e(format_datetime($job['updated_at'])); ?></td>
              <td>
                <a href="repair-view.php?id=<?php echo (int)$job['id']; ?>" class="btn btn-outline btn-xs">View</a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <?php echo empty_state('fas fa-tools', 'No repairs found', 'Jobs assigned to you will appear here.'); ?>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
