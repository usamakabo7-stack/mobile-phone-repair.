<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['admin']);

$pdo = db();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id AND role = 'customer' LIMIT 1");
$stmt->execute([':id' => $id]);
$customer = $stmt->fetch();

if (!$customer) {
    flash('error', 'Customer not found.');
    redirect('customers.php');
}

// Repair history for this customer
$stmt = $pdo->prepare(
    "SELECT r.*, t.full_name AS technician_name,
            (SELECT i.total FROM invoices i WHERE i.repair_id = r.id) AS total,
            (SELECT i.payment_status FROM invoices i WHERE i.repair_id = r.id) AS payment_status
     FROM repair_requests r
     LEFT JOIN users t ON t.id = r.technician_id
     WHERE r.customer_id = :cid
     ORDER BY r.created_at DESC"
);
$stmt->execute([':cid' => $id]);
$repairs = $stmt->fetchAll();

$page_title = $customer['full_name'];
$active = 'Customers';
require_once __DIR__ . '/../includes/dash-header.php';
?>

<div class="page-head">
  <div>
    <h1><?php echo e($customer['full_name']); ?></h1>
    <p>Customer details and repair history.</p>
  </div>
  <a href="customers.php" class="btn btn-outline btn-sm"><i class="fas fa-arrow-left"></i> Back</a>
</div>

<div class="card">
  <div class="card-header"><div class="card-title">Contact Information</div></div>
  <div class="card-body">
    <div class="meta-list">
      <div class="meta-item">
        <div class="m-label">Phone</div>
        <div class="m-value"><?php echo e($customer['phone']); ?></div>
      </div>
      <div class="meta-item">
        <div class="m-label">Email</div>
        <div class="m-value"><?php echo e($customer['email']); ?></div>
      </div>
      <div class="meta-item">
        <div class="m-label">Status</div>
        <div class="m-value"><?php echo ($customer['status'] === 'active') ? '<span class="badge badge-green">Active</span>' : '<span class="badge badge-red">Inactive</span>'; ?></div>
      </div>
      <div class="meta-item">
        <div class="m-label">Registered</div>
        <div class="m-value"><?php echo e(format_date($customer['created_at'])); ?></div>
      </div>
    </div>
  </div>
</div>

<div class="card">
  <div class="card-header"><div class="card-title">Repair History (<?php echo count($repairs); ?>)</div></div>
  <?php if ($repairs): ?>
    <div class="table-wrap">
      <table class="table">
        <thead>
          <tr>
            <th>Reference</th>
            <th>Device</th>
            <th>Technician</th>
            <th>Status</th>
            <th>Total</th>
            <th>Payment</th>
            <th>Date</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($repairs as $repair): ?>
            <tr>
              <td><strong><?php echo e($repair['reference']); ?></strong></td>
              <td><?php echo e($repair['brand'] . ' ' . $repair['model']); ?></td>
              <td><?php echo $repair['technician_name'] ? e($repair['technician_name']) : '—'; ?></td>
              <td><?php echo status_badge($repair['status']); ?></td>
              <td><?php echo $repair['total'] !== null ? format_money($repair['total']) : '—'; ?></td>
              <td><?php echo $repair['payment_status'] ? payment_badge($repair['payment_status']) : '—'; ?></td>
              <td class="table-muted"><?php echo e(format_date($repair['created_at'])); ?></td>
              <td><a href="repair-view.php?id=<?php echo (int)$repair['id']; ?>" class="btn btn-outline btn-xs">Open</a></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <?php echo empty_state('fas fa-tools', 'No repairs yet', 'This customer has not submitted any repair requests.'); ?>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
