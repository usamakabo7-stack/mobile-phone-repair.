<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['admin']);

$pdo = db();
$errors = [];

/* ---------- Add part ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    verify_csrf();

    $partName = isset($_POST['part_name']) ? trim($_POST['part_name']) : '';
    $category = isset($_POST['category']) ? trim($_POST['category']) : '';
    $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 0;
    $price    = isset($_POST['unit_price']) ? trim($_POST['unit_price']) : '0';
    $minStock = isset($_POST['min_stock']) ? (int)$_POST['min_stock'] : 0;

    if ($partName === '') {
        $errors[] = 'Part name is required.';
    }
    if ($quantity < 0) {
        $errors[] = 'Quantity must be 0 or more.';
    }
    if (!is_numeric($price) || (float)$price < 0) {
        $errors[] = 'Unit price must be a valid amount.';
    }
    if ($minStock < 0) {
        $errors[] = 'Minimum stock must be 0 or more.';
    }

    if (!$errors) {
        $stmt = $pdo->prepare(
            "INSERT INTO inventory (part_name, category, quantity, unit_price, min_stock, status)
             VALUES (:name, :cat, :qty, :price, :min, 'active')"
        );
        $stmt->execute([
            ':name'  => $partName,
            ':cat'   => $category,
            ':qty'   => $quantity,
            ':price' => (float)$price,
            ':min'   => $minStock,
        ]);
        flash('success', 'Part "' . $partName . '" added to inventory.');
        redirect('inventory.php');
    }
}

/* ---------- Toggle part status ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'toggle') {
    verify_csrf();
    $pid = isset($_POST['part_id']) ? (int)$_POST['part_id'] : 0;

    $stmt = $pdo->prepare("SELECT id, status FROM inventory WHERE id = :id LIMIT 1");
    $stmt->execute([':id' => $pid]);
    $part = $stmt->fetch();

    if (!$part) {
        flash('error', 'Part not found.');
    } else {
        $newStatus = ($part['status'] === 'active') ? 'inactive' : 'active';
        $stmt = $pdo->prepare("UPDATE inventory SET status = :s WHERE id = :id");
        $stmt->execute([':s' => $newStatus, ':id' => $pid]);
        flash('success', 'Part ' . $newStatus . 'd.');
    }
    redirect('inventory.php');
}

/* ---------- Restock (quick add quantity) ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'restock') {
    verify_csrf();
    $pid = isset($_POST['part_id']) ? (int)$_POST['part_id'] : 0;
    $add = isset($_POST['add_qty']) ? (int)$_POST['add_qty'] : 0;

    $stmt = $pdo->prepare("SELECT id FROM inventory WHERE id = :id LIMIT 1");
    $stmt->execute([':id' => $pid]);
    if (!$stmt->fetch()) {
        flash('error', 'Part not found.');
    } elseif ($add < 1) {
        flash('error', 'Restock quantity must be at least 1.');
    } else {
        $stmt = $pdo->prepare("UPDATE inventory SET quantity = quantity + :add, status = 'active' WHERE id = :id");
        $stmt->execute([':add' => $add, ':id' => $pid]);
        flash('success', 'Stock increased by ' . $add . '.');
    }
    redirect('inventory.php');
}

/* ---------- List ---------- */
$stmt = $pdo->query("SELECT * FROM inventory ORDER BY part_name");
$parts = $stmt->fetchAll();

$lowStockCount = 0;
foreach ($parts as $p) {
    if ((int)$p['quantity'] <= (int)$p['min_stock']) {
        $lowStockCount++;
    }
}

$page_title = 'Inventory';
$active = 'Inventory';
require_once __DIR__ . '/../includes/dash-header.php';
?>

<div class="page-head">
  <div>
    <h1>Inventory</h1>
    <p>Spare parts used during repairs.</p>
  </div>
  <?php if ($lowStockCount > 0): ?>
    <span class="badge badge-red"><i class="fas fa-exclamation-triangle"></i> <?php echo $lowStockCount; ?> low stock</span>
  <?php endif; ?>
</div>

<div class="grid-2">
  <div class="card">
    <div class="card-header"><div class="card-title">Add Part</div></div>
    <div class="card-body">
      <?php foreach ($errors as $error): ?>
        <div class="alert alert-error"><span><?php echo e($error); ?></span></div>
      <?php endforeach; ?>

      <form method="post" action="inventory.php" novalidate>
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="add">
        <div class="form-row">
          <div class="form-group">
            <label for="part_name">Part Name</label>
            <input type="text" class="form-control" id="part_name" name="part_name" placeholder="e.g. Samsung A15 Screen" required>
          </div>
          <div class="form-group">
            <label for="category">Category</label>
            <input type="text" class="form-control" id="category" name="category" placeholder="e.g. Screen">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label for="quantity">Quantity</label>
            <input type="number" min="0" class="form-control" id="quantity" name="quantity" value="0" required>
          </div>
          <div class="form-group">
            <label for="unit_price">Unit Price (₦)</label>
            <input type="number" step="0.01" min="0" class="form-control" id="unit_price" name="unit_price" value="0" required>
          </div>
          <div class="form-group">
            <label for="min_stock">Minimum Stock</label>
            <input type="number" min="0" class="form-control" id="min_stock" name="min_stock" value="0">
            <div class="form-hint">Alerts when stock reaches this level.</div>
          </div>
        </div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> Add Part</button>
      </form>
    </div>
  </div>

  <div class="card">
    <div class="card-header">
      <div class="card-title">Parts (<?php echo count($parts); ?>)</div>
      <div class="search-box">
        <i class="fas fa-search"></i>
        <input type="text" class="form-control" placeholder="Search parts..." data-target="#inventoryTable">
      </div>
    </div>
    <div class="table-wrap">
      <?php if ($parts): ?>
        <table class="table" id="inventoryTable">
          <thead>
            <tr>
              <th>Part</th>
              <th>Category</th>
              <th>Stock</th>
              <th>Unit Price</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($parts as $part): ?>
              <?php $isLow = (int)$part['quantity'] <= (int)$part['min_stock']; ?>
              <tr>
                <td><strong><?php echo e($part['part_name']); ?></strong></td>
                <td class="table-muted"><?php echo $part['category'] ? e($part['category']) : '—'; ?></td>
                <td>
                  <?php if ($isLow): ?>
                    <span class="qty-low"><?php echo (int)$part['quantity']; ?> <small>(min <?php echo (int)$part['min_stock']; ?>)</small></span>
                  <?php else: ?>
                    <span class="qty-ok"><?php echo (int)$part['quantity']; ?></span>
                  <?php endif; ?>
                </td>
                <td><?php echo format_money($part['unit_price']); ?></td>
                <td><?php echo ($part['status'] === 'active') ? '<span class="badge badge-green">Active</span>' : '<span class="badge badge-gray">Inactive</span>'; ?></td>
                <td>
                  <div class="table-actions">
                    <a href="inventory-edit.php?id=<?php echo (int)$part['id']; ?>" class="btn btn-outline btn-xs">Edit</a>
                    <form method="post" action="inventory.php" class="inline-form" data-confirm="Toggle this part's status?">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" name="action" value="toggle">
                      <input type="hidden" name="part_id" value="<?php echo (int)$part['id']; ?>">
                      <button type="submit" class="btn btn-ghost btn-xs"><?php echo ($part['status'] === 'active') ? 'Deactivate' : 'Activate'; ?></button>
                    </form>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <?php echo empty_state('fas fa-boxes', 'No parts yet', 'Add spare parts to use during repairs.'); ?>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
