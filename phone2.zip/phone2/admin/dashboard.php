<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['admin']);

$pdo = db();

// Status counts
$stmt = $pdo->query("SELECT status, COUNT(*) AS c FROM repair_requests GROUP BY status");
$counts = [];
foreach ($stmt->fetchAll() as $row) {
    $counts[$row['status']] = (int)$row['c'];
}
$total = array_sum($counts);

// Revenue quick stat
$stmt = $pdo->query("SELECT COALESCE(SUM(total),0) AS billed, COALESCE(SUM(CASE WHEN payment_status='Paid' THEN total ELSE 0 END),0) AS paid FROM invoices");
$rev = $stmt->fetch();

// Recent repairs
$stmt = $pdo->query(
    "SELECT r.id, r.reference, r.brand, r.model, r.status, r.created_at,
            u.full_name AS customer_name,
            t.full_name AS technician_name
     FROM repair_requests r
     JOIN users u ON u.id = r.customer_id
     LEFT JOIN users t ON t.id = r.technician_id
     ORDER BY r.created_at DESC LIMIT 8"
);
$recent = $stmt->fetchAll();

$page_title = 'Dashboard';
$active = 'Dashboard';
require_once __DIR__ . '/../includes/dash-header.php';
?>

<div class="page-head">
  <div>
    <h1>Dashboard</h1>
    <p>Overview of repairs across the system.</p>
  </div>
</div>

<div class="stat-grid">
  <div class="stat-card navy">
    <div class="stat-icon"><i class="fas fa-clipboard-list"></i></div>
    <div>
      <div class="stat-value"><?php echo $total; ?></div>
      <div class="stat-label">Total Repairs</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon"><i class="fas fa-hourglass-half"></i></div>
    <div>
      <div class="stat-value"><?php echo isset($counts['Pending']) ? $counts['Pending'] : 0; ?></div>
      <div class="stat-label">Pending</div>
    </div>
  </div>
  <div class="stat-card yellow">
    <div class="stat-icon"><i class="fas fa-tools"></i></div>
    <div>
      <div class="stat-value"><?php echo isset($counts['Repairing']) ? $counts['Repairing'] : 0; ?></div>
      <div class="stat-label">Repairing</div>
    </div>
  </div>
  <div class="stat-card green">
    <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
    <div>
      <div class="stat-value"><?php echo isset($counts['Completed']) ? $counts['Completed'] : 0; ?></div>
      <div class="stat-label">Completed</div>
    </div>
  </div>
</div>

<div class="stat-grid">
  <div class="stat-card blue">
    <div class="stat-icon"><i class="fas fa-file-invoice"></i></div>
    <div>
      <div class="stat-value"><?php echo format_money($rev['billed']); ?></div>
      <div class="stat-label">Total Billed</div>
    </div>
  </div>
  <div class="stat-card green">
    <div class="stat-icon"><i class="fas fa-wallet"></i></div>
    <div>
      <div class="stat-value"><?php echo format_money($rev['paid']); ?></div>
      <div class="stat-label">Total Paid</div>
    </div>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <div class="card-title">Recent Repair Requests</div>
    <a href="repairs.php" class="btn btn-ghost btn-sm">View all <i class="fas fa-arrow-right"></i></a>
  </div>
  <?php if ($recent): ?>
    <div class="table-wrap">
      <table class="table">
        <thead>
          <tr>
            <th>Reference</th>
            <th>Customer</th>
            <th>Device</th>
            <th>Technician</th>
            <th>Status</th>
            <th>Date</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($recent as $repair): ?>
            <tr>
              <td><strong><?php echo e($repair['reference']); ?></strong></td>
              <td><?php echo e($repair['customer_name']); ?></td>
              <td><?php echo e($repair['brand'] . ' ' . $repair['model']); ?></td>
              <td><?php echo $repair['technician_name'] ? e($repair['technician_name']) : '<span class="badge badge-gray">Unassigned</span>'; ?></td>
              <td><?php echo status_badge($repair['status']); ?></td>
              <td class="table-muted"><?php echo e(format_date($repair['created_at'])); ?></td>
              <td><a href="repair-view.php?id=<?php echo (int)$repair['id']; ?>" class="btn btn-outline btn-xs">Open</a></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <?php echo empty_state('fas fa-inbox', 'No repairs yet', 'Customer repair requests will appear here.'); ?>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
