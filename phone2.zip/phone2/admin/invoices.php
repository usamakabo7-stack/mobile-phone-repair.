<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['admin']);

$pdo = db();

/* ---------- Mark invoice paid ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'mark_paid') {
    verify_csrf();
    $invId = isset($_POST['invoice_id']) ? (int)$_POST['invoice_id'] : 0;

    $stmt = $pdo->prepare("SELECT id FROM invoices WHERE id = :id LIMIT 1");
    $stmt->execute([':id' => $invId]);
    if (!$stmt->fetch()) {
        flash('error', 'Invoice not found.');
    } else {
        $stmt = $pdo->prepare("UPDATE invoices SET payment_status = 'Paid' WHERE id = :id");
        $stmt->execute([':id' => $invId]);
        flash('success', 'Invoice marked as paid.');
    }
    redirect('invoices.php');
}

/* ---------- List ---------- */
$paymentFilter = isset($_GET['payment']) ? trim($_GET['payment']) : '';
$sql = "SELECT i.*, r.reference, r.brand, r.model, r.status AS repair_status, u.full_name AS customer_name
        FROM invoices i
        JOIN repair_requests r ON r.id = i.repair_id
        JOIN users u ON u.id = i.customer_id
        WHERE 1=1";
$params = [];

if ($paymentFilter === 'Paid' || $paymentFilter === 'Unpaid') {
    $sql .= " AND i.payment_status = :p";
    $params[':p'] = $paymentFilter;
}
$sql .= " ORDER BY i.created_at DESC LIMIT 300";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$invoices = $stmt->fetchAll();

$page_title = 'Invoices';
$active = 'Invoices';
require_once __DIR__ . '/../includes/dash-header.php';
?>

<div class="page-head">
  <div>
    <h1>Invoices</h1>
    <p>All generated invoices and payment status.</p>
  </div>
  <form method="get" action="invoices.php" class="filter-bar">
    <select name="payment" class="form-control">
      <option value="">All Payments</option>
      <option value="Paid" <?php echo ($paymentFilter === 'Paid') ? 'selected' : ''; ?>>Paid</option>
      <option value="Unpaid" <?php echo ($paymentFilter === 'Unpaid') ? 'selected' : ''; ?>>Unpaid</option>
    </select>
    <button type="submit" class="btn btn-outline btn-sm">Filter</button>
  </form>
</div>

<div class="card">
  <?php if ($invoices): ?>
    <div class="table-wrap">
      <table class="table">
        <thead>
          <tr>
            <th>Invoice No</th>
            <th>Repair</th>
            <th>Customer</th>
            <th>Device</th>
            <th>Total</th>
            <th>Payment</th>
            <th>Date</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($invoices as $inv): ?>
            <tr>
              <td><strong><?php echo e($inv['invoice_no']); ?></strong></td>
              <td><?php echo e($inv['reference']); ?></td>
              <td><?php echo e($inv['customer_name']); ?></td>
              <td><?php echo e($inv['brand'] . ' ' . $inv['model']); ?></td>
              <td><?php echo format_money($inv['total']); ?></td>
              <td><?php echo payment_badge($inv['payment_status']); ?></td>
              <td class="table-muted"><?php echo e(format_date($inv['created_at'])); ?></td>
              <td>
                <div class="table-actions">
                  <a href="invoice-view.php?id=<?php echo (int)$inv['id']; ?>" class="btn btn-outline btn-xs">View</a>
                  <?php if ($inv['payment_status'] === 'Unpaid'): ?>
                    <form method="post" action="invoices.php" class="inline-form" data-confirm="Mark this invoice as paid?">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" name="action" value="mark_paid">
                      <input type="hidden" name="invoice_id" value="<?php echo (int)$inv['id']; ?>">
                      <button type="submit" class="btn btn-green btn-xs">Mark Paid</button>
                    </form>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <?php echo empty_state('fas fa-file-invoice', 'No invoices found', 'Invoices are generated automatically when repairs are billed.'); ?>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
