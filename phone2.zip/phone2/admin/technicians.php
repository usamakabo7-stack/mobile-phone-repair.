<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['admin']);

$pdo = db();

$errors = [];

/* ---------- Add technician ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    verify_csrf();

    $fullName = isset($_POST['full_name']) ? trim($_POST['full_name']) : '';
    $phone    = isset($_POST['phone']) ? trim($_POST['phone']) : '';
    $email    = isset($_POST['email']) ? strtolower(trim($_POST['email'])) : '';
    $spec     = isset($_POST['specialization']) ? trim($_POST['specialization']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $confirm  = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';

    if ($fullName === '') {
        $errors[] = 'Full name is required.';
    }
    if ($phone === '') {
        $errors[] = 'Phone number is required.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }
    if (strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters.';
    } elseif ($password !== $confirm) {
        $errors[] = 'Passwords do not match.';
    }

    if (!$errors) {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = :email LIMIT 1");
        $stmt->execute([':email' => $email]);
        if ($stmt->fetch()) {
            $errors[] = 'A user with this email already exists.';
        }
    }

    if (!$errors) {
        $stmt = $pdo->prepare(
            "INSERT INTO users (full_name, phone, email, password, role, specialization, status)
             VALUES (:name, :phone, :email, :pass, 'technician', :spec, 'active')"
        );
        $stmt->execute([
            ':name'  => $fullName,
            ':phone' => $phone,
            ':email' => $email,
            ':pass'  => password_hash($password, PASSWORD_DEFAULT),
            ':spec'  => $spec,
        ]);
        flash('success', 'Technician ' . $fullName . ' added successfully.');
        redirect('technicians.php');
    }
}

/* ---------- Toggle technician status ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'toggle') {
    verify_csrf();
    $tid = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;

    $stmt = $pdo->prepare("SELECT id, status, role FROM users WHERE id = :id AND role = 'technician' LIMIT 1");
    $stmt->execute([':id' => $tid]);
    $user = $stmt->fetch();

    if (!$user) {
        flash('error', 'Technician not found.');
    } else {
        $newStatus = ($user['status'] === 'active') ? 'inactive' : 'active';
        $stmt = $pdo->prepare("UPDATE users SET status = :s WHERE id = :id");
        $stmt->execute([':s' => $newStatus, ':id' => $tid]);
        flash('success', 'Technician account ' . $newStatus . 'd.');
    }
    redirect('technicians.php');
}

/* ---------- List ---------- */
$stmt = $pdo->prepare(
    "SELECT u.*,
            (SELECT COUNT(*) FROM repair_requests r WHERE r.technician_id = u.id) AS total_jobs,
            (SELECT COUNT(*) FROM repair_requests r WHERE r.technician_id = u.id AND r.status IN ('Completed','Collected')) AS done_jobs
     FROM users u WHERE u.role = 'technician' ORDER BY u.full_name"
);
$stmt->execute();
$technicians = $stmt->fetchAll();

$page_title = 'Technicians';
$active = 'Technicians';
require_once __DIR__ . '/../includes/dash-header.php';
?>

<div class="page-head">
  <div>
    <h1>Technicians</h1>
    <p>Manage the repair team and their access.</p>
  </div>
</div>

<div class="grid-2">
  <div class="card">
    <div class="card-header"><div class="card-title">Add Technician</div></div>
    <div class="card-body">
      <?php foreach ($errors as $error): ?>
        <div class="alert alert-error"><span><?php echo e($error); ?></span></div>
      <?php endforeach; ?>

      <form method="post" action="technicians.php" novalidate>
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="add">
        <div class="form-row">
          <div class="form-group">
            <label for="full_name">Full Name</label>
            <input type="text" class="form-control" id="full_name" name="full_name" placeholder="e.g. Musa Ibrahim" required>
          </div>
          <div class="form-group">
            <label for="phone">Phone</label>
            <input type="tel" class="form-control" id="phone" name="phone" placeholder="e.g. 08012345678" required>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control" id="email" name="email" placeholder="e.g. technician@example.com" required>
          </div>
          <div class="form-group">
            <label for="specialization">Specialization</label>
            <input type="text" class="form-control" id="specialization" name="specialization" placeholder="e.g. Screen & Battery">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label for="password">Password</label>
            <input type="password" class="form-control" id="password" name="password" minlength="6" required>
          </div>
          <div class="form-group">
            <label for="confirm_password">Confirm Password</label>
            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
          </div>
        </div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-user-plus"></i> Add Technician</button>
      </form>
    </div>
  </div>

  <div class="card">
    <div class="card-header"><div class="card-title">Technician Team (<?php echo count($technicians); ?>)</div></div>
    <div class="table-wrap">
      <?php if ($technicians): ?>
        <table class="table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Specialization</th>
              <th>Jobs</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($technicians as $tech): ?>
              <tr>
                <td>
                  <strong><?php echo e($tech['full_name']); ?></strong>
                  <div class="small table-muted"><?php echo e($tech['email']); ?></div>
                </td>
                <td><?php echo $tech['specialization'] ? e($tech['specialization']) : '—'; ?></td>
                <td><?php echo (int)$tech['done_jobs'] . '/' . (int)$tech['total_jobs']; ?></td>
                <td><?php echo ($tech['status'] === 'active') ? '<span class="badge badge-green">Active</span>' : '<span class="badge badge-red">Inactive</span>'; ?></td>
                <td>
                  <div class="table-actions">
                    <a href="technicians-edit.php?id=<?php echo (int)$tech['id']; ?>" class="btn btn-outline btn-xs">Edit</a>
                    <form method="post" action="technicians.php" class="inline-form" data-confirm="Toggle this technician's account status?">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" name="action" value="toggle">
                      <input type="hidden" name="user_id" value="<?php echo (int)$tech['id']; ?>">
                      <button type="submit" class="btn btn-ghost btn-xs">
                        <?php echo ($tech['status'] === 'active') ? 'Deactivate' : 'Activate'; ?>
                      </button>
                    </form>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <?php echo empty_state('fas fa-user-cog', 'No technicians yet', 'Add your first technician to start assigning repairs.'); ?>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
