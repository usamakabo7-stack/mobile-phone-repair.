<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['admin']);

$pdo = db();
$adminId = current_user_id();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$repair = get_repair($pdo, $id);

if (!$repair) {
    flash('error', 'Repair not found.');
    redirect('repairs.php');
}

$errors = [];

/* ---------- Assign / reassign technician ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'assign') {
    verify_csrf();

    if (!is_open($repair['status'])) {
        $errors[] = 'This repair can no longer be assigned.';
    } else {
        $techId = isset($_POST['technician_id']) ? (int)$_POST['technician_id'] : 0;

        $stmt = $pdo->prepare("SELECT id FROM users WHERE id = :id AND role = 'technician' AND status = 'active' LIMIT 1");
        $stmt->execute([':id' => $techId]);
        if (!$stmt->fetch()) {
            $errors[] = 'Please select a valid, active technician.';
        }

        if (!$errors) {
            $wasPending = ($repair['status'] === 'Pending');
            $newStatus  = $wasPending ? 'Assigned' : $repair['status'];

            $stmt = $pdo->prepare("UPDATE repair_requests SET technician_id = :tech, status = :status WHERE id = :id");
            $stmt->execute([':tech' => $techId, ':status' => $newStatus, ':id' => $repair['id']]);

            if ($wasPending) {
                log_status($pdo, $repair['id'], 'Assigned', 'Assigned to technician.', $adminId);
            } else {
                log_status($pdo, $repair['id'], $newStatus, 'Technician reassigned.', $adminId);
            }

            flash('success', 'Technician assigned to this repair.');
            redirect('repair-view.php?id=' . $repair['id']);
        }
    }
}

/* ---------- Cancel repair ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'cancel') {
    verify_csrf();

    if (!can_cancel($repair['status'])) {
        $errors[] = 'This repair cannot be cancelled at its current stage.';
    } elseif (cancel_repair($pdo, $repair['id'], $adminId)) {
        flash('success', 'Repair cancelled. Any reserved stock has been restored.');
        redirect('repair-view.php?id=' . $repair['id']);
    } else {
        $errors[] = 'Could not cancel the repair. Please try again.';
    }
}

/* ---------- Mark as collected ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'collect') {
    verify_csrf();

    if ($repair['status'] !== 'Completed') {
        $errors[] = 'Only completed repairs can be marked as collected.';
    } else {
        $stmt = $pdo->prepare("UPDATE repair_requests SET status = 'Collected', collected_at = :now WHERE id = :id");
        $stmt->execute([':now' => date('Y-m-d H:i:s'), ':id' => $repair['id']]);
        log_status($pdo, $repair['id'], 'Collected', 'Device collected by customer.', $adminId);
        flash('success', 'Repair marked as collected.');
        redirect('repair-view.php?id=' . $repair['id']);
    }
}

/* ---------- Mark invoice paid ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'mark_paid') {
    verify_csrf();

    $invoice = get_invoice_for_repair($pdo, $repair['id']);
    if (!$invoice) {
        $errors[] = 'No invoice exists for this repair yet.';
    } else {
        $stmt = $pdo->prepare("UPDATE invoices SET payment_status = 'Paid' WHERE id = :id");
        $stmt->execute([':id' => $invoice['id']]);
        flash('success', 'Invoice marked as paid.');
        redirect('repair-view.php?id=' . $repair['id']);
    }
}

/* ---------- Load display data ---------- */
$history = get_history($pdo, $repair['id']);
$parts   = get_repair_parts($pdo, $repair['id']);
$invoice = get_invoice_for_repair($pdo, $repair['id']);
$partsCost = parts_cost_for_repair($pdo, $repair['id']);

// Active technicians for assignment
$stmt = $pdo->query("SELECT id, full_name, specialization FROM users WHERE role = 'technician' AND status = 'active' ORDER BY full_name");
$technicians = $stmt->fetchAll();

$page_title = $repair['reference'];
$active = 'Repairs';
require_once __DIR__ . '/../includes/dash-header.php';
?>

<div class="page-head">
  <div>
    <h1><?php echo e($repair['reference']); ?></h1>
    <p>Submitted <?php echo e(format_datetime($repair['created_at'])); ?></p>
  </div>
  <?php echo status_badge($repair['status']); ?>
</div>

<?php foreach ($errors as $error): ?>
  <div class="alert alert-error"><span><?php echo e($error); ?></span></div>
<?php endforeach; ?>

<div class="grid-2">
  <div>
    <div class="card">
      <div class="card-header"><div class="card-title">Repair Details</div></div>
      <div class="card-body">
        <div class="meta-list">
          <div class="meta-item">
            <div class="m-label">Customer</div>
            <div class="m-value"><?php echo e($repair['customer_name']); ?></div>
          </div>
          <div class="meta-item">
            <div class="m-label">Phone</div>
            <div class="m-value"><?php echo e($repair['customer_phone']); ?></div>
          </div>
          <div class="meta-item">
            <div class="m-label">Device</div>
            <div class="m-value"><?php echo e($repair['brand'] . ' ' . $repair['model']); ?></div>
          </div>
          <div class="meta-item">
            <div class="m-label">Problem Type</div>
            <div class="m-value"><?php echo e($repair['problem_type']); ?></div>
          </div>
          <?php if ($repair['imei']): ?>
            <div class="meta-item">
              <div class="m-label">IMEI</div>
              <div class="m-value"><?php echo e($repair['imei']); ?></div>
            </div>
          <?php endif; ?>
          <div class="meta-item">
            <div class="m-label">Assigned Technician</div>
            <div class="m-value"><?php echo $repair['technician_name'] ? e($repair['technician_name']) : '<span class="badge badge-gray">Unassigned</span>'; ?></div>
          </div>
        </div>
        <hr class="divider">
        <div class="m-label mb-1">Customer Description</div>
        <p class="muted"><?php echo nl2br(e($repair['description'])); ?></p>

        <?php if ($repair['diagnosis']): ?>
          <hr class="divider">
          <div class="m-label mb-1">Diagnosis</div>
          <p class="muted"><?php echo nl2br(e($repair['diagnosis'])); ?></p>
        <?php endif; ?>
        <?php if ($repair['repair_notes']): ?>
          <hr class="divider">
          <div class="m-label mb-1">Repair Notes</div>
          <p class="muted"><?php echo nl2br(e($repair['repair_notes'])); ?></p>
        <?php endif; ?>
      </div>
    </div>

    <div class="card">
      <div class="card-header"><div class="card-title">Billing</div></div>
      <div class="card-body">
        <div class="meta-list">
          <div class="meta-item">
            <div class="m-label">Service / Labour</div>
            <div class="m-value"><?php echo format_money($repair['service_cost']); ?></div>
          </div>
          <div class="meta-item">
            <div class="m-label">Parts</div>
            <div class="m-value"><?php echo format_money($partsCost); ?></div>
          </div>
          <div class="meta-item">
            <div class="m-label">Total</div>
            <div class="m-value"><?php echo format_money((float)$repair['service_cost'] + $partsCost); ?></div>
          </div>
          <?php if ($invoice): ?>
            <div class="meta-item">
              <div class="m-label">Invoice</div>
              <div class="m-value"><?php echo e($invoice['invoice_no']); ?></div>
            </div>
            <div class="meta-item">
              <div class="m-label">Payment</div>
              <div class="m-value"><?php echo payment_badge($invoice['payment_status']); ?></div>
            </div>
          <?php endif; ?>
        </div>

        <?php if ($parts): ?>
          <hr class="divider">
          <table class="table">
            <thead><tr><th>Part</th><th>Qty</th><th class="text-right">Amount</th></tr></thead>
            <tbody>
              <?php foreach ($parts as $part): ?>
                <tr>
                  <td><?php echo e($part['part_name']); ?></td>
                  <td><?php echo (int)$part['quantity']; ?></td>
                  <td class="text-right"><?php echo format_money($part['subtotal']); ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>

        <?php if ($invoice): ?>
          <div class="form-actions mt-3">
            <a href="invoice-view.php?id=<?php echo (int)$invoice['id']; ?>" class="btn btn-outline btn-sm"><i class="fas fa-file-invoice"></i> View Invoice</a>
            <?php if ($invoice['payment_status'] === 'Unpaid'): ?>
              <form method="post" action="repair-view.php?id=<?php echo (int)$repair['id']; ?>" class="inline-form">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="mark_paid">
                <button type="submit" class="btn btn-green btn-sm"><i class="fas fa-check"></i> Mark Paid</button>
              </form>
            <?php endif; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div>
    <div class="card">
      <div class="card-header"><div class="card-title">Assignment</div></div>
      <div class="card-body">
        <?php if (is_open($repair['status'])): ?>
          <form method="post" action="repair-view.php?id=<?php echo (int)$repair['id']; ?>" novalidate>
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="assign">
            <div class="form-group">
              <label for="technician_id">
                <?php echo $repair['technician_name'] ? 'Reassign Technician' : 'Assign Technician'; ?>
              </label>
              <select class="form-control" id="technician_id" name="technician_id" required>
                <option value="">-- Select technician --</option>
                <?php foreach ($technicians as $tech): ?>
                  <option value="<?php echo (int)$tech['id']; ?>" <?php echo ($repair['technician_id'] == $tech['id']) ? 'selected' : ''; ?>>
                    <?php echo e($tech['full_name']); ?><?php echo $tech['specialization'] ? ' · ' . e($tech['specialization']) : ''; ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-user-check"></i> Assign Job</button>
          </form>
        <?php else: ?>
          <p class="muted small">This repair is no longer open for assignment.</p>
        <?php endif; ?>
      </div>
    </div>

    <div class="card">
      <div class="card-header"><div class="card-title">Actions</div></div>
      <div class="card-body">
        <?php if ($repair['status'] === 'Completed'): ?>
          <form method="post" action="repair-view.php?id=<?php echo (int)$repair['id']; ?>" class="mb-2">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="collect">
            <button type="submit" class="btn btn-navy btn-block"><i class="fas fa-check-double"></i> Mark Collected</button>
          </form>
        <?php endif; ?>

        <?php if (can_cancel($repair['status'])): ?>
          <form method="post" action="repair-view.php?id=<?php echo (int)$repair['id']; ?>" data-confirm="Cancel this repair? Any reserved stock will be restored.">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="cancel">
            <button type="submit" class="btn btn-danger btn-block"><i class="fas fa-times-circle"></i> Cancel Repair</button>
          </form>
        <?php endif; ?>
      </div>
    </div>

    <div class="card">
      <div class="card-header"><div class="card-title">Repair Progress</div></div>
      <div class="card-body">
        <?php echo repair_timeline($history, $repair['status']); ?>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
