<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['admin']);

$pdo = db();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$stmt = $pdo->prepare("SELECT * FROM inventory WHERE id = :id LIMIT 1");
$stmt->execute([':id' => $id]);
$part = $stmt->fetch();

if (!$part) {
    flash('error', 'Part not found.');
    redirect('inventory.php');
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $partName = isset($_POST['part_name']) ? trim($_POST['part_name']) : '';
    $category = isset($_POST['category']) ? trim($_POST['category']) : '';
    $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 0;
    $price    = isset($_POST['unit_price']) ? trim($_POST['unit_price']) : '0';
    $minStock = isset($_POST['min_stock']) ? (int)$_POST['min_stock'] : 0;
    $status   = (isset($_POST['status']) && $_POST['status'] === 'inactive') ? 'inactive' : 'active';

    if ($partName === '') {
        $errors[] = 'Part name is required.';
    }
    if ($quantity < 0) {
        $errors[] = 'Quantity must be 0 or more.';
    }
    if (!is_numeric($price) || (float)$price < 0) {
        $errors[] = 'Unit price must be a valid amount.';
    }
    if ($minStock < 0) {
        $errors[] = 'Minimum stock must be 0 or more.';
    }

    if (!$errors) {
        $stmt = $pdo->prepare(
            "UPDATE inventory SET part_name = :name, category = :cat, quantity = :qty,
                    unit_price = :price, min_stock = :min, status = :status WHERE id = :id"
        );
        $stmt->execute([
            ':name'  => $partName,
            ':cat'   => $category,
            ':qty'   => $quantity,
            ':price' => (float)$price,
            ':min'   => $minStock,
            ':status' => $status,
            ':id'    => $id,
        ]);
        flash('success', 'Part updated successfully.');
        redirect('inventory.php');
    }
}

$page_title = 'Edit Part';
$active = 'Inventory';
require_once __DIR__ . '/../includes/dash-header.php';
?>

<div class="page-head">
  <div>
    <h1>Edit Part</h1>
    <p><?php echo e($part['part_name']); ?></p>
  </div>
  <a href="inventory.php" class="btn btn-outline btn-sm"><i class="fas fa-arrow-left"></i> Back</a>
</div>

<div class="card" style="max-width:640px;">
  <div class="card-body">
    <?php foreach ($errors as $error): ?>
      <div class="alert alert-error"><span><?php echo e($error); ?></span></div>
    <?php endforeach; ?>

    <form method="post" action="inventory-edit.php?id=<?php echo (int)$part['id']; ?>" novalidate>
      <?php echo csrf_field(); ?>
      <div class="form-group">
        <label for="part_name">Part Name</label>
        <input type="text" class="form-control" id="part_name" name="part_name" value="<?php echo e($part['part_name']); ?>" required>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label for="category">Category</label>
          <input type="text" class="form-control" id="category" name="category" value="<?php echo e($part['category']); ?>">
        </div>
        <div class="form-group">
          <label for="status">Status</label>
          <select class="form-control" id="status" name="status">
            <option value="active" <?php echo ($part['status'] === 'active') ? 'selected' : ''; ?>>Active</option>
            <option value="inactive" <?php echo ($part['status'] === 'inactive') ? 'selected' : ''; ?>>Inactive</option>
          </select>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label for="quantity">Quantity on Hand</label>
          <input type="number" min="0" class="form-control" id="quantity" name="quantity" value="<?php echo (int)$part['quantity']; ?>" required>
          <div class="form-hint">Set the current stock level directly.</div>
        </div>
        <div class="form-group">
          <label for="unit_price">Unit Price (₦)</label>
          <input type="number" step="0.01" min="0" class="form-control" id="unit_price" name="unit_price" value="<?php echo e(number_format((float)$part['unit_price'], 2, '.', '')); ?>" required>
        </div>
        <div class="form-group">
          <label for="min_stock">Minimum Stock</label>
          <input type="number" min="0" class="form-control" id="min_stock" name="min_stock" value="<?php echo (int)$part['min_stock']; ?>">
        </div>
      </div>
      <div class="form-actions">
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Changes</button>
        <a href="inventory.php" class="btn btn-outline">Cancel</a>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
