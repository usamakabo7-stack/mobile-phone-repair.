<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['admin']);

$pdo = db();

$statusFilter = isset($_GET['status']) ? trim($_GET['status']) : '';
$search       = isset($_GET['q']) ? trim($_GET['q']) : '';
$allowed      = ['Pending', 'Assigned', 'Diagnosing', 'Repairing', 'Completed', 'Collected', 'Cancelled'];

$sql = "SELECT r.*, u.full_name AS customer_name, t.full_name AS technician_name
        FROM repair_requests r
        JOIN users u ON u.id = r.customer_id
        LEFT JOIN users t ON t.id = r.technician_id
        WHERE 1=1";
$params = [];

if ($statusFilter !== '' && in_array($statusFilter, $allowed, true)) {
    $sql .= " AND r.status = :status";
    $params[':status'] = $statusFilter;
}

if ($search !== '') {
    $sql .= " AND (r.reference LIKE :q OR u.full_name LIKE :q OR r.brand LIKE :q OR r.model LIKE :q)";
    $params[':q'] = '%' . $search . '%';
}

$sql .= " ORDER BY r.created_at DESC LIMIT 200";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$repairs = $stmt->fetchAll();

$page_title = 'Repairs';
$active = 'Repairs';
require_once __DIR__ . '/../includes/dash-header.php';
?>

<div class="page-head">
  <div>
    <h1>Repairs</h1>
    <p>Review and manage all repair requests.</p>
  </div>
  <form method="get" action="repairs.php" class="filter-bar">
    <div class="search-box">
      <i class="fas fa-search"></i>
      <input type="text" class="form-control" name="q" placeholder="Search reference, customer, device..." value="<?php echo e($search); ?>">
    </div>
    <select name="status" class="form-control">
      <option value="">All Statuses</option>
      <?php foreach ($allowed as $s): ?>
        <option value="<?php echo e($s); ?>" <?php echo ($statusFilter === $s) ? 'selected' : ''; ?>><?php echo e($s); ?></option>
      <?php endforeach; ?>
    </select>
    <button type="submit" class="btn btn-outline btn-sm">Filter</button>
    <?php if ($statusFilter !== '' || $search !== ''): ?>
      <a href="repairs.php" class="btn btn-ghost btn-sm">Reset</a>
    <?php endif; ?>
  </form>
</div>

<div class="card">
  <?php if ($repairs): ?>
    <div class="table-wrap">
      <table class="table">
        <thead>
          <tr>
            <th>Reference</th>
            <th>Customer</th>
            <th>Device</th>
            <th>Problem</th>
            <th>Technician</th>
            <th>Status</th>
            <th>Date</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($repairs as $repair): ?>
            <tr>
              <td><strong><?php echo e($repair['reference']); ?></strong></td>
              <td><?php echo e($repair['customer_name']); ?></td>
              <td><?php echo e($repair['brand'] . ' ' . $repair['model']); ?></td>
              <td class="table-muted"><?php echo e($repair['problem_type']); ?></td>
              <td><?php echo $repair['technician_name'] ? e($repair['technician_name']) : '<span class="badge badge-gray">Unassigned</span>'; ?></td>
              <td><?php echo status_badge($repair['status']); ?></td>
              <td class="table-muted"><?php echo e(format_date($repair['created_at'])); ?></td>
              <td><a href="repair-view.php?id=<?php echo (int)$repair['id']; ?>" class="btn btn-outline btn-xs">Open</a></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <?php echo empty_state('fas fa-inbox', 'No repairs found', 'Try changing your search or filter.'); ?>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
