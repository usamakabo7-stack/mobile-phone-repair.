<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['admin']);

$pdo = db();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$stmt = $pdo->prepare(
    "SELECT i.*, r.reference, r.brand, r.model, r.problem_type, r.status AS repair_status,
            u.full_name AS customer_name, u.phone AS customer_phone, u.email AS customer_email
     FROM invoices i
     JOIN repair_requests r ON r.id = i.repair_id
     JOIN users u ON u.id = i.customer_id
     WHERE i.id = :id LIMIT 1"
);
$stmt->execute([':id' => $id]);
$invoice = $stmt->fetch();

if (!$invoice) {
    flash('error', 'Invoice not found.');
    redirect('invoices.php');
}

/* ---------- Mark paid ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'mark_paid') {
    verify_csrf();
    $stmt = $pdo->prepare("UPDATE invoices SET payment_status = 'Paid' WHERE id = :id");
    $stmt->execute([':id' => $invoice['id']]);
    flash('success', 'Invoice marked as paid.');
    redirect('invoice-view.php?id=' . $invoice['id']);
}

$stmt = $pdo->prepare("SELECT * FROM invoice_items WHERE invoice_id = :inv ORDER BY id");
$stmt->execute([':inv' => $invoice['id']]);
$items = $stmt->fetchAll();

$page_title = $invoice['invoice_no'];
$active = 'Invoices';
require_once __DIR__ . '/../includes/dash-header.php';
?>

<div class="page-head">
  <div>
    <h1>Invoice <?php echo e($invoice['invoice_no']); ?></h1>
    <p>Repair <?php echo e($invoice['reference']); ?> · <?php echo e($invoice['customer_name']); ?></p>
  </div>
  <div class="no-print form-actions">
    <a href="invoices.php" class="btn btn-outline"><i class="fas fa-arrow-left"></i> All Invoices</a>
    <button type="button" class="btn btn-navy" onclick="window.print()"><i class="fas fa-print"></i> Print Invoice</button>
  </div>
</div>

<div class="invoice-wrap">
  <div class="invoice">
    <div class="inv-head">
      <div>
        <div class="inv-brand"><span>Mobile</span><span>Fix</span></div>
        <div class="inv-brand-sub">Repair Management System</div>
      </div>
      <div class="inv-no">
        <?php echo e($invoice['invoice_no']); ?>
        <small><?php echo e($invoice['reference']); ?> · <?php echo e(format_date($invoice['created_at'])); ?></small>
      </div>
    </div>

    <div class="inv-row">
      <div>
        <div class="inv-label">Billed To</div>
        <div class="inv-value"><?php echo e($invoice['customer_name']); ?></div>
        <div class="small muted"><?php echo e($invoice['customer_phone']); ?></div>
        <div class="small muted"><?php echo e($invoice['customer_email']); ?></div>
      </div>
      <div>
        <div class="inv-label">Device</div>
        <div class="inv-value"><?php echo e($invoice['brand'] . ' ' . $invoice['model']); ?></div>
        <div class="small muted"><?php echo e($invoice['problem_type']); ?></div>
        <div class="small muted">Status: <?php echo e($invoice['repair_status']); ?></div>
      </div>
    </div>

    <table class="inv-table">
      <thead>
        <tr><th>Description</th><th class="text-right">Qty</th><th class="text-right">Unit Price</th><th class="text-right">Amount</th></tr>
      </thead>
      <tbody>
        <?php foreach ($items as $item): ?>
          <tr>
            <td><?php echo e($item['description']); ?></td>
            <td class="num"><?php echo (int)$item['quantity']; ?></td>
            <td class="num"><?php echo format_money($item['unit_price']); ?></td>
            <td class="num"><?php echo format_money($item['amount']); ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <div class="inv-totals">
      <div class="inv-total-line"><span>Service / Labour</span><span><?php echo format_money($invoice['service_cost']); ?></span></div>
      <div class="inv-total-line"><span>Parts</span><span><?php echo format_money($invoice['parts_cost']); ?></span></div>
      <div class="inv-total-line grand"><span>Total</span><span><?php echo format_money($invoice['total']); ?></span></div>
      <div class="inv-total-line"><span>Payment</span><span><?php echo payment_badge($invoice['payment_status']); ?></span></div>
    </div>

    <div class="inv-foot">
      Thank you for choosing MobileFix.<br>
      Device is ready for collection after payment at our service centre.
    </div>
  </div>

  <div class="no-print form-actions mt-3" style="justify-content:center;">
    <?php if ($invoice['payment_status'] === 'Unpaid'): ?>
      <form method="post" action="invoice-view.php?id=<?php echo (int)$invoice['id']; ?>" data-confirm="Mark this invoice as paid?">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="mark_paid">
        <button type="submit" class="btn btn-green"><i class="fas fa-check-circle"></i> Mark as Paid</button>
      </form>
    <?php else: ?>
      <span class="badge badge-green" style="font-size:0.9rem;"><i class="fas fa-check-circle"></i> Payment received</span>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
