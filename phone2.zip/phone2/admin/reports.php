<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['admin']);

$pdo = db();

/* ---------- Date filter ---------- */
$from = isset($_GET['from']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['from']) ? $_GET['from'] : '';
$to   = isset($_GET['to']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['to']) ? $_GET['to'] : '';

$where  = '';
$params = [];
if ($from !== '') {
    $where .= " AND DATE(r.created_at) >= :from";
    $params[':from'] = $from;
}
if ($to !== '') {
    $where .= " AND DATE(r.created_at) <= :to";
    $params[':to'] = $to;
}

/* ---------- Repair summary by status ---------- */
$stmt = $pdo->prepare("SELECT r.status, COUNT(*) AS c FROM repair_requests r WHERE 1=1" . $where . " GROUP BY r.status");
$stmt->execute($params);
$statusCounts = [];
foreach ($stmt->fetchAll() as $row) {
    $statusCounts[$row['status']] = (int)$row['c'];
}

/* ---------- Revenue summary ---------- */
$stmt = $pdo->prepare(
    "SELECT COALESCE(SUM(i.total),0) AS billed,
            COALESCE(SUM(CASE WHEN i.payment_status='Paid' THEN i.total ELSE 0 END),0) AS paid,
            COALESCE(SUM(CASE WHEN i.payment_status='Unpaid' THEN i.total ELSE 0 END),0) AS unpaid,
            COUNT(i.id) AS invoice_count
     FROM invoices i
     JOIN repair_requests r ON r.id = i.repair_id
     WHERE 1=1" . $where
);
$stmt->execute($params);
$revenue = $stmt->fetch();

/* ---------- Technician summary ---------- */
$stmt = $pdo->prepare(
    "SELECT u.full_name, u.specialization,
            COUNT(r.id) AS assigned,
            SUM(CASE WHEN r.status IN ('Completed','Collected') THEN 1 ELSE 0 END) AS completed,
            SUM(CASE WHEN r.status IN ('Assigned','Diagnosing','Repairing') THEN 1 ELSE 0 END) AS active
     FROM users u
     LEFT JOIN repair_requests r ON r.technician_id = u.id
     WHERE u.role = 'technician'" . $where . "
     GROUP BY u.id, u.full_name, u.specialization
     ORDER BY assigned DESC"
);
$stmt->execute($params);
$technicians = $stmt->fetchAll();

/* ---------- Inventory summary ---------- */
$totalParts = (int)$pdo->query("SELECT COUNT(*) FROM inventory")->fetchColumn();
$lowParts = (int)$pdo->query("SELECT COUNT(*) FROM inventory WHERE quantity <= min_stock")->fetchColumn();

$page_title = 'Reports';
$active = 'Reports';
require_once __DIR__ . '/../includes/dash-header.php';
?>

<div class="page-head">
  <div>
    <h1>Reports</h1>
    <p>Simple summaries of repairs, revenue, technicians and inventory.</p>
  </div>
  <form method="get" action="reports.php" class="filter-bar">
    <input type="date" class="form-control" name="from" value="<?php echo e($from); ?>">
    <span class="muted small">to</span>
    <input type="date" class="form-control" name="to" value="<?php echo e($to); ?>">
    <button type="submit" class="btn btn-outline btn-sm">Apply</button>
    <?php if ($from !== '' || $to !== ''): ?>
      <a href="reports.php" class="btn btn-ghost btn-sm">Reset</a>
    <?php endif; ?>
  </form>
</div>

<div class="card">
  <div class="card-header"><div class="card-title">Repair Summary</div></div>
  <div class="card-body">
    <div class="stat-grid" style="margin-bottom:0;">
      <div class="stat-card navy">
        <div class="stat-icon"><i class="fas fa-clipboard-list"></i></div>
        <div><div class="stat-value"><?php echo array_sum($statusCounts); ?></div><div class="stat-label">Total Repairs</div></div>
      </div>
      <?php foreach (['Pending', 'Assigned', 'Diagnosing', 'Repairing', 'Completed', 'Collected', 'Cancelled'] as $s): ?>
        <div class="stat-card">
          <div class="stat-icon"><i class="fas fa-circle" style="font-size:0.9rem; color:<?php echo badge_color($s); ?>;"></i></div>
          <div>
            <div class="stat-value"><?php echo isset($statusCounts[$s]) ? $statusCounts[$s] : 0; ?></div>
            <div class="stat-label"><?php echo e($s); ?></div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<div class="card">
  <div class="card-header"><div class="card-title">Revenue Summary</div></div>
  <div class="card-body">
    <div class="stat-grid" style="margin-bottom:0;">
      <div class="stat-card blue">
        <div class="stat-icon"><i class="fas fa-file-invoice"></i></div>
        <div><div class="stat-value"><?php echo format_money($revenue['billed']); ?></div><div class="stat-label">Total Billed</div></div>
      </div>
      <div class="stat-card green">
        <div class="stat-icon"><i class="fas fa-wallet"></i></div>
        <div><div class="stat-value"><?php echo format_money($revenue['paid']); ?></div><div class="stat-label">Total Paid</div></div>
      </div>
      <div class="stat-card red">
        <div class="stat-icon"><i class="fas fa-clock"></i></div>
        <div><div class="stat-value"><?php echo format_money($revenue['unpaid']); ?></div><div class="stat-label">Total Unpaid</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon"><i class="fas fa-receipt"></i></div>
        <div><div class="stat-value"><?php echo (int)$revenue['invoice_count']; ?></div><div class="stat-label">Invoices</div></div>
      </div>
    </div>
  </div>
</div>

<div class="grid-2">
  <div class="card">
    <div class="card-header"><div class="card-title">Technician Summary</div></div>
    <div class="table-wrap">
      <table class="table">
        <thead>
          <tr>
            <th>Technician</th>
            <th>Assigned</th>
            <th>Active</th>
            <th>Completed</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($technicians): ?>
            <?php foreach ($technicians as $tech): ?>
              <tr>
                <td><strong><?php echo e($tech['full_name']); ?></strong>
                  <?php if ($tech['specialization']): ?><div class="small table-muted"><?php echo e($tech['specialization']); ?></div><?php endif; ?>
                </td>
                <td><?php echo (int)$tech['assigned']; ?></td>
                <td><?php echo (int)$tech['active']; ?></td>
                <td><?php echo (int)$tech['completed']; ?></td>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr><td colspan="4" class="text-center table-muted">No technicians.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <div class="card">
    <div class="card-header"><div class="card-title">Inventory Summary</div></div>
    <div class="card-body">
      <div class="stat-grid" style="margin-bottom:0;">
        <div class="stat-card">
          <div class="stat-icon"><i class="fas fa-boxes"></i></div>
          <div><div class="stat-value"><?php echo $totalParts; ?></div><div class="stat-label">Total Parts</div></div>
        </div>
        <div class="stat-card red">
          <div class="stat-icon"><i class="fas fa-exclamation-triangle"></i></div>
          <div><div class="stat-value"><?php echo $lowParts; ?></div><div class="stat-label">Low Stock Parts</div></div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
