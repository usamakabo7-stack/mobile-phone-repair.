<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['admin']);

$pdo = db();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id AND role = 'technician' LIMIT 1");
$stmt->execute([':id' => $id]);
$technician = $stmt->fetch();

if (!$technician) {
    flash('error', 'Technician not found.');
    redirect('technicians.php');
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $fullName = isset($_POST['full_name']) ? trim($_POST['full_name']) : '';
    $phone    = isset($_POST['phone']) ? trim($_POST['phone']) : '';
    $email    = isset($_POST['email']) ? strtolower(trim($_POST['email'])) : '';
    $spec     = isset($_POST['specialization']) ? trim($_POST['specialization']) : '';
    $status   = (isset($_POST['status']) && $_POST['status'] === 'inactive') ? 'inactive' : 'active';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $confirm  = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';

    if ($fullName === '') {
        $errors[] = 'Full name is required.';
    }
    if ($phone === '') {
        $errors[] = 'Phone number is required.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }
    if ($password !== '') {
        if (strlen($password) < 6) {
            $errors[] = 'Password must be at least 6 characters.';
        } elseif ($password !== $confirm) {
            $errors[] = 'Passwords do not match.';
        }
    }

    if (!$errors) {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = :email AND id != :id LIMIT 1");
        $stmt->execute([':email' => $email, ':id' => $id]);
        if ($stmt->fetch()) {
            $errors[] = 'That email is already used by another account.';
        }
    }

    if (!$errors) {
        if ($password !== '') {
            $stmt = $pdo->prepare(
                "UPDATE users SET full_name = :name, phone = :phone, email = :email,
                        specialization = :spec, status = :status, password = :pass WHERE id = :id"
            );
            $stmt->execute([
                ':name'  => $fullName,
                ':phone' => $phone,
                ':email' => $email,
                ':spec'  => $spec,
                ':status' => $status,
                ':pass'  => password_hash($password, PASSWORD_DEFAULT),
                ':id'    => $id,
            ]);
        } else {
            $stmt = $pdo->prepare(
                "UPDATE users SET full_name = :name, phone = :phone, email = :email,
                        specialization = :spec, status = :status WHERE id = :id"
            );
            $stmt->execute([
                ':name'  => $fullName,
                ':phone' => $phone,
                ':email' => $email,
                ':spec'  => $spec,
                ':status' => $status,
                ':id'    => $id,
            ]);
        }
        flash('success', 'Technician updated successfully.');
        redirect('technicians.php');
    }
}

$page_title = 'Edit Technician';
$active = 'Technicians';
require_once __DIR__ . '/../includes/dash-header.php';
?>

<div class="page-head">
  <div>
    <h1>Edit Technician</h1>
    <p><?php echo e($technician['full_name']); ?></p>
  </div>
  <a href="technicians.php" class="btn btn-outline btn-sm"><i class="fas fa-arrow-left"></i> Back</a>
</div>

<div class="card" style="max-width:760px;">
  <div class="card-body">
    <?php foreach ($errors as $error): ?>
      <div class="alert alert-error"><span><?php echo e($error); ?></span></div>
    <?php endforeach; ?>

    <form method="post" action="technicians-edit.php?id=<?php echo (int)$technician['id']; ?>" novalidate>
      <?php echo csrf_field(); ?>
      <div class="form-row">
        <div class="form-group">
          <label for="full_name">Full Name</label>
          <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo e($technician['full_name']); ?>" required>
        </div>
        <div class="form-group">
          <label for="phone">Phone</label>
          <input type="tel" class="form-control" id="phone" name="phone" value="<?php echo e($technician['phone']); ?>" required>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label for="email">Email</label>
          <input type="email" class="form-control" id="email" name="email" value="<?php echo e($technician['email']); ?>" required>
        </div>
        <div class="form-group">
          <label for="specialization">Specialization</label>
          <input type="text" class="form-control" id="specialization" name="specialization" value="<?php echo e($technician['specialization']); ?>">
        </div>
      </div>
      <div class="form-group">
        <label for="status">Status</label>
        <select class="form-control" id="status" name="status">
          <option value="active" <?php echo ($technician['status'] === 'active') ? 'selected' : ''; ?>>Active</option>
          <option value="inactive" <?php echo ($technician['status'] === 'inactive') ? 'selected' : ''; ?>>Inactive</option>
        </select>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label for="password">New Password <span class="muted small">(leave blank to keep current)</span></label>
          <input type="password" class="form-control" id="password" name="password">
        </div>
        <div class="form-group">
          <label for="confirm_password">Confirm New Password</label>
          <input type="password" class="form-control" id="confirm_password" name="confirm_password">
        </div>
      </div>
      <div class="form-actions">
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Changes</button>
        <a href="technicians.php" class="btn btn-outline">Cancel</a>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
