<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['admin']);

$pdo = db();

/* ---------- Activate / deactivate customer ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'toggle') {
    verify_csrf();
    $cid = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;

    $stmt = $pdo->prepare("SELECT id, status, role FROM users WHERE id = :id AND role = 'customer' LIMIT 1");
    $stmt->execute([':id' => $cid]);
    $user = $stmt->fetch();

    if (!$user) {
        flash('error', 'Customer not found.');
    } else {
        $newStatus = ($user['status'] === 'active') ? 'inactive' : 'active';
        $stmt = $pdo->prepare("UPDATE users SET status = :s WHERE id = :id");
        $stmt->execute([':s' => $newStatus, ':id' => $cid]);
        flash('success', 'Customer account ' . $newStatus . 'd.');
    }
    redirect('customers.php');
}

/* ---------- Search & list ---------- */
$search = isset($_GET['q']) ? trim($_GET['q']) : '';
$sql = "SELECT u.*, (SELECT COUNT(*) FROM repair_requests r WHERE r.customer_id = u.id) AS repair_count
        FROM users u WHERE u.role = 'customer'";
$params = [];

if ($search !== '') {
    $sql .= " AND (u.full_name LIKE :q OR u.email LIKE :q OR u.phone LIKE :q)";
    $params[':q'] = '%' . $search . '%';
}
$sql .= " ORDER BY u.created_at DESC LIMIT 300";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$customers = $stmt->fetchAll();

$page_title = 'Customers';
$active = 'Customers';
require_once __DIR__ . '/../includes/dash-header.php';
?>

<div class="page-head">
  <div>
    <h1>Customers</h1>
    <p>Registered customers and their repair activity.</p>
  </div>
  <form method="get" action="customers.php" class="filter-bar">
    <div class="search-box">
      <i class="fas fa-search"></i>
      <input type="text" class="form-control" name="q" placeholder="Search name, email or phone..." value="<?php echo e($search); ?>">
    </div>
    <button type="submit" class="btn btn-outline btn-sm">Search</button>
    <?php if ($search !== ''): ?><a href="customers.php" class="btn btn-ghost btn-sm">Reset</a><?php endif; ?>
  </form>
</div>

<div class="card">
  <?php if ($customers): ?>
    <div class="table-wrap">
      <table class="table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Repairs</th>
            <th>Status</th>
            <th>Registered</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($customers as $customer): ?>
            <tr>
              <td><strong><?php echo e($customer['full_name']); ?></strong></td>
              <td><?php echo e($customer['phone']); ?></td>
              <td class="table-muted"><?php echo e($customer['email']); ?></td>
              <td><?php echo (int)$customer['repair_count']; ?></td>
              <td><?php echo ($customer['status'] === 'active') ? '<span class="badge badge-green">Active</span>' : '<span class="badge badge-red">Inactive</span>'; ?></td>
              <td class="table-muted"><?php echo e(format_date($customer['created_at'])); ?></td>
              <td>
                <div class="table-actions">
                  <a href="customers-view.php?id=<?php echo (int)$customer['id']; ?>" class="btn btn-outline btn-xs">View</a>
                  <form method="post" action="customers.php" class="inline-form" data-confirm="Toggle this customer's account status?">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="action" value="toggle">
                    <input type="hidden" name="user_id" value="<?php echo (int)$customer['id']; ?>">
                    <button type="submit" class="btn btn-ghost btn-xs">
                      <?php echo ($customer['status'] === 'active') ? 'Deactivate' : 'Activate'; ?>
                    </button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <?php echo empty_state('fas fa-users', 'No customers found', 'Try a different search.'); ?>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
